'use client'

import { useState, useCallback, useEffect, useRef } from 'react'
import {
  LineStyle,
  Trash2,
  Copy,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  ChevronDown,
  Move,
  Layers,
  MoreHorizontal,
  Settings,
  X,
  Square,
  Minus,
  AlignLeft,
} from 'lucide-react'

export interface DrawingSettings {
  color: string
  lineWidth: number
  lineStyle: 'solid' | 'dashed' | 'dotted'
  opacity: number
  locked: boolean
  visible: boolean
}

interface DrawingSettingsMenuProps {
  isOpen: boolean
  drawingType: string | null
  settings: DrawingSettings
  onSettingsChange: (settings: DrawingSettings) => void
  onDelete: () => void
  onDuplicate: () => void
  onClose: () => void
  position?: { x: number; y: number }
}

const PRESET_COLORS = [
  '#f59e0b', // amber (default)
  '#ef4444', // red
  '#22c55e', // green
  '#3b82f6', // blue
  '#8b5cf6', // purple
  '#ec4899', // pink
  '#06b6d4', // cyan
  '#f97316', // orange
  '#84cc16', // lime
  '#ffffff', // white
  '#6b7280', // gray
  '#000000', // black
]

const LINE_WIDTHS = [1, 2, 3, 4, 5]

// Dropdown component - defined outside to avoid "component during render" error
function Dropdown({ 
  isOpen, 
  children, 
  className = '' 
}: { 
  isOpen: boolean
  children: React.ReactNode
  className?: string 
}) {
  if (!isOpen) return null
  return (
    <div 
      className={`absolute top-full left-0 mt-1 bg-zinc-900 border border-zinc-700 rounded-md shadow-xl z-50 ${className}`}
      onClick={(e) => e.stopPropagation()}
    >
      {children}
    </div>
  )
}

export function DrawingSettingsMenu({
  isOpen,
  drawingType,
  settings,
  onSettingsChange,
  onDelete,
  onDuplicate,
  onClose,
  position,
}: DrawingSettingsMenuProps) {
  const [showColorPicker, setShowColorPicker] = useState(false)
  const [showLineWidth, setShowLineWidth] = useState(false)
  const [showLineStyle, setShowLineStyle] = useState(false)
  const [showOpacity, setShowOpacity] = useState(false)
  const [showMore, setShowMore] = useState(false)

  const menuRef = useRef<HTMLDivElement>(null)
  const colorPickerRef = useRef<HTMLDivElement>(null)
  const lineWidthRef = useRef<HTMLDivElement>(null)
  const lineStyleRef = useRef<HTMLDivElement>(null)
  const opacityRef = useRef<HTMLDivElement>(null)
  const moreRef = useRef<HTMLDivElement>(null)

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (colorPickerRef.current && !colorPickerRef.current.contains(e.target as Node)) {
        setShowColorPicker(false)
      }
      if (lineWidthRef.current && !lineWidthRef.current.contains(e.target as Node)) {
        setShowLineWidth(false)
      }
      if (lineStyleRef.current && !lineStyleRef.current.contains(e.target as Node)) {
        setShowLineStyle(false)
      }
      if (opacityRef.current && !opacityRef.current.contains(e.target as Node)) {
        setShowOpacity(false)
      }
      if (moreRef.current && !moreRef.current.contains(e.target as Node)) {
        setShowMore(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const handleColorChange = useCallback((color: string) => {
    onSettingsChange({ ...settings, color })
    setShowColorPicker(false)
  }, [settings, onSettingsChange])

  const handleLineWidthChange = useCallback((width: number) => {
    onSettingsChange({ ...settings, lineWidth: width })
    setShowLineWidth(false)
  }, [settings, onSettingsChange])

  const handleLineStyleChange = useCallback((style: 'solid' | 'dashed' | 'dotted') => {
    onSettingsChange({ ...settings, lineStyle: style })
    setShowLineStyle(false)
  }, [settings, onSettingsChange])

  const handleOpacityChange = useCallback((opacity: number) => {
    onSettingsChange({ ...settings, opacity })
  }, [settings, onSettingsChange])

  const toggleLocked = useCallback(() => {
    onSettingsChange({ ...settings, locked: !settings.locked })
  }, [settings, onSettingsChange])

  const toggleVisible = useCallback(() => {
    onSettingsChange({ ...settings, visible: !settings.visible })
  }, [settings, onSettingsChange])

  if (!isOpen || !drawingType) return null

  const getDrawingTypeName = () => {
    switch (drawingType) {
      case 'pencil': return 'Карандаш'
      case 'hray': return 'Горизонтальный луч'
      case 'hline': return 'Горизонтальная линия'
      case 'trendline': return 'Линия тренда'
      case 'trendray': return 'Трендовый луч'
      case 'rectangle': return 'Прямоугольник'
      case 'fibonacci': return 'Фибоначчи'
      case 'ruler': return 'Рулетка'
      default: return drawingType
    }
  }

  return (
    <div 
      ref={menuRef}
      className="absolute top-2 left-1/2 -translate-x-1/2 z-50"
      onClick={(e) => e.stopPropagation()}
    >
      {/* Main container */}
      <div className="bg-zinc-900/95 backdrop-blur border border-zinc-700 rounded-lg shadow-2xl overflow-hidden">
        {/* Header with title and close button */}
        <div className="flex items-center justify-between px-3 py-1.5 border-b border-zinc-700/50 bg-zinc-800/50">
          <span className="text-xs font-medium text-zinc-300">{getDrawingTypeName()}</span>
          <button
            onClick={onClose}
            className="p-0.5 rounded hover:bg-zinc-700 text-zinc-400 hover:text-white transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Toolbar */}
        <div className="flex items-center gap-0.5 px-2 py-1.5">
          {/* Color picker */}
          <div className="relative" ref={colorPickerRef}>
            <button
              onClick={() => {
                setShowColorPicker(!showColorPicker)
                setShowLineWidth(false)
                setShowLineStyle(false)
                setShowOpacity(false)
                setShowMore(false)
              }}
              className="flex items-center gap-1 px-2 py-1 rounded hover:bg-zinc-700/50 transition-colors group"
              title="Цвет"
            >
              <div 
                className="w-5 h-5 rounded border border-zinc-600 group-hover:border-zinc-500"
                style={{ backgroundColor: settings.color }}
              />
              <ChevronDown className="w-3 h-3 text-zinc-400" />
            </button>

            <Dropdown isOpen={showColorPicker} className="p-2 w-52">
              <div className="text-xs text-zinc-400 mb-2 px-1">Цвет линии</div>
              <div className="grid grid-cols-6 gap-1 mb-2">
                {PRESET_COLORS.map((color) => (
                  <button
                    key={color}
                    onClick={() => handleColorChange(color)}
                    className={`w-7 h-7 rounded border-2 transition-all hover:scale-110 ${
                      settings.color === color ? 'border-white' : 'border-transparent'
                    }`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
              <div className="border-t border-zinc-700 pt-2 mt-1">
                <div className="text-xs text-zinc-400 mb-1.5 px-1">Пользовательский</div>
                <input
                  type="color"
                  value={settings.color}
                  onChange={(e) => handleColorChange(e.target.value)}
                  className="w-full h-8 rounded cursor-pointer bg-zinc-800 border border-zinc-600"
                />
              </div>
            </Dropdown>
          </div>

          {/* Separator */}
          <div className="w-px h-6 bg-zinc-700 mx-1" />

          {/* Line width */}
          <div className="relative" ref={lineWidthRef}>
            <button
              onClick={() => {
                setShowLineWidth(!showLineWidth)
                setShowColorPicker(false)
                setShowLineStyle(false)
                setShowOpacity(false)
                setShowMore(false)
              }}
              className="flex items-center gap-1 px-2 py-1 rounded hover:bg-zinc-700/50 transition-colors"
              title="Толщина линии"
            >
              <div className="flex flex-col gap-0.5 w-4 h-4 items-center justify-center">
                {LINE_WIDTHS.slice(0, 3).map((w) => (
                  <div
                    key={w}
                    className="w-full rounded-full bg-zinc-300"
                    style={{ 
                      height: `${Math.min(w, 3)}px`,
                      opacity: settings.lineWidth === w ? 1 : 0.4
                    }}
                  />
                ))}
              </div>
              <span className="text-xs text-zinc-300 min-w-[20px]">{settings.lineWidth}px</span>
              <ChevronDown className="w-3 h-3 text-zinc-400" />
            </button>

            <Dropdown isOpen={showLineWidth} className="p-1.5">
              <div className="text-xs text-zinc-400 mb-1.5 px-2">Толщина линии</div>
              <div className="flex flex-col gap-0.5">
                {LINE_WIDTHS.map((width) => (
                  <button
                    key={width}
                    onClick={() => handleLineWidthChange(width)}
                    className={`flex items-center gap-3 px-2 py-1.5 rounded hover:bg-zinc-700 transition-colors ${
                      settings.lineWidth === width ? 'bg-zinc-700' : ''
                    }`}
                  >
                    <div className="w-8 flex items-center justify-center">
                      <div
                        className="w-full rounded-full bg-zinc-300"
                        style={{ height: `${width}px` }}
                      />
                    </div>
                    <span className="text-xs text-zinc-300">{width}px</span>
                  </button>
                ))}
              </div>
            </Dropdown>
          </div>

          {/* Line style */}
          <div className="relative" ref={lineStyleRef}>
            <button
              onClick={() => {
                setShowLineStyle(!showLineStyle)
                setShowColorPicker(false)
                setShowLineWidth(false)
                setShowOpacity(false)
                setShowMore(false)
              }}
              className="flex items-center gap-1 px-2 py-1 rounded hover:bg-zinc-700/50 transition-colors"
              title="Стиль линии"
            >
              {settings.lineStyle === 'solid' && (
                <Minus className="w-4 h-4 text-zinc-300" />
              )}
              {settings.lineStyle === 'dashed' && (
                <div className="w-4 h-0.5 flex gap-0.5">
                  <div className="flex-1 bg-zinc-300" />
                  <div className="w-1" />
                  <div className="flex-1 bg-zinc-300" />
                </div>
              )}
              {settings.lineStyle === 'dotted' && (
                <div className="w-4 h-1 flex gap-0.5 items-center justify-center">
                  <div className="w-1 h-1 rounded-full bg-zinc-300" />
                  <div className="w-1 h-1 rounded-full bg-zinc-300" />
                  <div className="w-1 h-1 rounded-full bg-zinc-300" />
                </div>
              )}
              <ChevronDown className="w-3 h-3 text-zinc-400" />
            </button>

            <Dropdown isOpen={showLineStyle} className="p-1.5 w-40">
              <div className="text-xs text-zinc-400 mb-1.5 px-2">Стиль линии</div>
              <div className="flex flex-col gap-0.5">
                <button
                  onClick={() => handleLineStyleChange('solid')}
                  className={`flex items-center gap-3 px-2 py-1.5 rounded hover:bg-zinc-700 transition-colors ${
                    settings.lineStyle === 'solid' ? 'bg-zinc-700' : ''
                  }`}
                >
                  <div className="w-8 h-0.5 bg-zinc-300" />
                  <span className="text-xs text-zinc-300">Сплошная</span>
                </button>
                <button
                  onClick={() => handleLineStyleChange('dashed')}
                  className={`flex items-center gap-3 px-2 py-1.5 rounded hover:bg-zinc-700 transition-colors ${
                    settings.lineStyle === 'dashed' ? 'bg-zinc-700' : ''
                  }`}
                >
                  <div className="w-8 h-0.5 flex gap-0.5">
                    <div className="flex-1 bg-zinc-300" />
                    <div className="w-1" />
                    <div className="flex-1 bg-zinc-300" />
                  </div>
                  <span className="text-xs text-zinc-300">Пунктирная</span>
                </button>
                <button
                  onClick={() => handleLineStyleChange('dotted')}
                  className={`flex items-center gap-3 px-2 py-1.5 rounded hover:bg-zinc-700 transition-colors ${
                    settings.lineStyle === 'dotted' ? 'bg-zinc-700' : ''
                  }`}
                >
                  <div className="w-8 h-1 flex gap-1 items-center justify-center">
                    <div className="w-1 h-1 rounded-full bg-zinc-300" />
                    <div className="w-1 h-1 rounded-full bg-zinc-300" />
                    <div className="w-1 h-1 rounded-full bg-zinc-300" />
                    <div className="w-1 h-1 rounded-full bg-zinc-300" />
                  </div>
                  <span className="text-xs text-zinc-300">Точечная</span>
                </button>
              </div>
            </Dropdown>
          </div>

          {/* Opacity */}
          <div className="relative" ref={opacityRef}>
            <button
              onClick={() => {
                setShowOpacity(!showOpacity)
                setShowColorPicker(false)
                setShowLineWidth(false)
                setShowLineStyle(false)
                setShowMore(false)
              }}
              className="flex items-center gap-1 px-2 py-1 rounded hover:bg-zinc-700/50 transition-colors"
              title="Прозрачность"
            >
              <Layers className="w-4 h-4 text-zinc-300" />
              <span className="text-xs text-zinc-300">{Math.round(settings.opacity * 100)}%</span>
              <ChevronDown className="w-3 h-3 text-zinc-400" />
            </button>

            <Dropdown isOpen={showOpacity} className="p-3 w-48">
              <div className="text-xs text-zinc-400 mb-2">Прозрачность</div>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.opacity * 100}
                onChange={(e) => handleOpacityChange(parseInt(e.target.value) / 100)}
                className="w-full h-2 bg-zinc-700 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
              <div className="flex justify-between text-xs text-zinc-500 mt-1">
                <span>0%</span>
                <span>{Math.round(settings.opacity * 100)}%</span>
                <span>100%</span>
              </div>
            </Dropdown>
          </div>

          {/* Separator */}
          <div className="w-px h-6 bg-zinc-700 mx-1" />

          {/* Visibility toggle */}
          <button
            onClick={toggleVisible}
            className={`p-1.5 rounded hover:bg-zinc-700/50 transition-colors ${
              settings.visible ? 'text-zinc-300' : 'text-zinc-500'
            }`}
            title={settings.visible ? 'Скрыть' : 'Показать'}
          >
            {settings.visible ? (
              <Eye className="w-4 h-4" />
            ) : (
              <EyeOff className="w-4 h-4" />
            )}
          </button>

          {/* Lock toggle */}
          <button
            onClick={toggleLocked}
            className={`p-1.5 rounded hover:bg-zinc-700/50 transition-colors ${
              settings.locked ? 'text-amber-400' : 'text-zinc-300'
            }`}
            title={settings.locked ? 'Разблокировать' : 'Заблокировать'}
          >
            {settings.locked ? (
              <Lock className="w-4 h-4" />
            ) : (
              <Unlock className="w-4 h-4" />
            )}
          </button>

          {/* Separator */}
          <div className="w-px h-6 bg-zinc-700 mx-1" />

          {/* Duplicate */}
          <button
            onClick={onDuplicate}
            className="p-1.5 rounded hover:bg-zinc-700/50 transition-colors text-zinc-300"
            title="Дублировать"
          >
            <Copy className="w-4 h-4" />
          </button>

          {/* More options */}
          <div className="relative" ref={moreRef}>
            <button
              onClick={() => {
                setShowMore(!showMore)
                setShowColorPicker(false)
                setShowLineWidth(false)
                setShowLineStyle(false)
                setShowOpacity(false)
              }}
              className="p-1.5 rounded hover:bg-zinc-700/50 transition-colors text-zinc-300"
              title="Дополнительно"
            >
              <MoreHorizontal className="w-4 h-4" />
            </button>

            <Dropdown isOpen={showMore} className="p-1 w-44">
              <div className="flex flex-col gap-0.5">
                <button
                  onClick={() => {
                    onDuplicate()
                    setShowMore(false)
                  }}
                  className="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-zinc-700 transition-colors text-left"
                >
                  <Copy className="w-4 h-4 text-zinc-400" />
                  <span className="text-xs text-zinc-300">Дублировать</span>
                </button>
                <button
                  onClick={() => {
                    toggleLocked()
                    setShowMore(false)
                  }}
                  className="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-zinc-700 transition-colors text-left"
                >
                  {settings.locked ? (
                    <>
                      <Unlock className="w-4 h-4 text-zinc-400" />
                      <span className="text-xs text-zinc-300">Разблокировать</span>
                    </>
                  ) : (
                    <>
                      <Lock className="w-4 h-4 text-zinc-400" />
                      <span className="text-xs text-zinc-300">Заблокировать</span>
                    </>
                  )}
                </button>
                <div className="h-px bg-zinc-700 my-1" />
                <button
                  onClick={() => {
                    onDelete()
                    setShowMore(false)
                  }}
                  className="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-red-900/50 transition-colors text-left"
                >
                  <Trash2 className="w-4 h-4 text-red-400" />
                  <span className="text-xs text-red-400">Удалить</span>
                </button>
              </div>
            </Dropdown>
          </div>

          {/* Delete */}
          <button
            onClick={onDelete}
            className="p-1.5 rounded hover:bg-red-900/30 transition-colors text-zinc-400 hover:text-red-400"
            title="Удалить"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  )
}

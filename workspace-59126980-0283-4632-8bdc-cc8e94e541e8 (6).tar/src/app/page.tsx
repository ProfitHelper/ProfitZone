'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import {
  createChart,
  IChartApi,
  ISeriesApi,
  CandlestickData,
  HistogramData,
  ColorType,
  Time,
  CandlestickSeries,
  HistogramSeries,
  CandlestickSeriesOptions,
  HistogramSeriesOptions,
  LogicalRange,
  Logical,
} from 'lightweight-charts'
import { ScrollArea } from '@/components/ui/scroll-area'
import { TrendingUp, TrendingDown, ChevronLeft, ChevronRight, LayoutGrid, Maximize2, Pencil, Ruler } from 'lucide-react'
import { MiniChart } from '@/components/charts/mini-chart'
import { DrawingSettingsMenu, DrawingSettings } from '@/components/drawing-settings-menu'

interface CandleData {
  time: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

interface ApiResponse {
  symbol: string
  interval: string
  candles: CandleData[]
}

interface Ticker {
  symbol: string
  baseAsset: string
  priceChangePercent: number
  lastPrice: number
  highPrice: number
  lowPrice: number
  volume: number
  count: number
}

interface ChartViewState {
  logicalRange: { from: number; to: number } | null
  rightOffset: number
}

// Drawing types
interface DrawingPoint {
  price: number
  logicalIndex: number // Logical index on the time scale (works for any position)
  time: number // Time value for compatibility with other functions
}

type DrawingType = 'pencil' | 'hray' | 'hline' | 'trendline' | 'trendray' | 'rectangle' | 'fibonacci' | 'ruler'
type LineStyle = 'solid' | 'dashed' | 'dotted'

interface Drawing {
  id: string
  type: DrawingType
  symbol: string
  interval: string
  points: DrawingPoint[]
  color: string
  lineWidth: number
  lineStyle: LineStyle
  opacity: number
  locked: boolean
  visible: boolean
}

// Default drawing settings
const DEFAULT_DRAWING_SETTINGS: Omit<Drawing, 'id' | 'type' | 'symbol' | 'interval' | 'points'> = {
  color: '#f59e0b',
  lineWidth: 2,
  lineStyle: 'solid',
  opacity: 1,
  locked: false,
  visible: true,
}

// Page modes
type PageMode = 'single' | 'multi'

export default function Home() {
  const [pageMode, setPageMode] = useState<PageMode>('single')

  // Multi-chart state
  const [multiChartIntervals, setMultiChartIntervals] = useState<Record<string, string>>({})

  // Single chart state
  const chartContainerRef = useRef<HTMLDivElement>(null)
  const chartRef = useRef<IChartApi | null>(null)
  const candlestickSeriesRef = useRef<ISeriesApi<'Candlestick', Time, CandlestickData<Time>, CandlestickSeriesOptions> | null>(null)
  const volumeSeriesRef = useRef<ISeriesApi<'Histogram', Time, HistogramData<Time>, HistogramSeriesOptions> | null>(null)
  const drawingCanvasRef = useRef<HTMLCanvasElement | null>(null)

  const viewStateMapRef = useRef<Map<string, ChartViewState>>(new Map())
  const isLoadingDataRef = useRef(false)
  const currentSymbolRef = useRef<string>('')
  const currentIntervalRef = useRef<string>('')
  const drawingsRef = useRef<Map<string, Drawing[]>>(new Map())
  const currentDrawingRef = useRef<Drawing | null>(null)
  const isDrawingRef = useRef(false)
  const drawOnCanvasRef = useRef<(() => void) | null>(null)
  const mousePositionRef = useRef<{ x: number; y: number; price: number; logicalIndex: number; time: number } | null>(null)
  const plotAreaRef = useRef<{ width: number; height: number }>({ width: 0, height: 0 })
  const timeoutRef = useRef<NodeJS.Timeout | null>(null)
  const tempRulerRef = useRef<Drawing | null>(null) // Temporary ruler for middle mouse button
  const isTempRulerRef = useRef(false) // Flag for temporary ruler mode
  const isDraggingRef = useRef(false) // Flag for dragging a drawing
  const dragStartRef = useRef<{ x: number; y: number; drawing: Drawing } | null>(null) // Drag start state
  const dragHandleRef = useRef<{ drawingId: string; handleIndex: number } | null>(null) // Which handle is being dragged

  // Helper to convert coordinates to price/time
  const coordinateToPrice = useCallback((x: number, y: number): DrawingPoint | null => {
    if (!chartRef.current || !candlestickSeriesRef.current) return null

    const chart = chartRef.current
    const series = candlestickSeriesRef.current
    const timeScale = chart.timeScale()

    const price = series.coordinateToPrice(y)
    const logicalIndex = timeScale.coordinateToLogical(x)
    const time = timeScale.coordinateToTime(x)

    if (price === null || logicalIndex === null) return null

    return { price, logicalIndex: logicalIndex as number, time: (time as number) ?? 0 }
  }, [])

  const [tickers, setTickers] = useState<Ticker[]>([])
  const [selectedSymbol, setSelectedSymbol] = useState('BTCUSDT')
  const [selectedInterval, setSelectedInterval] = useState('5m')
  const [loading, setLoading] = useState(true)
  const [tickersLoading, setTickersLoading] = useState(true)
  const [showTickers, setShowTickers] = useState(true)
  const [showRightPanel, setShowRightPanel] = useState(true) // Right panel visibility
  const [scrollOffset, setScrollOffset] = useState(0)
  const [drawingTool, setDrawingTool] = useState<string | null>(null)
  const [selectedDrawingId, setSelectedDrawingId] = useState<string | null>(null)

  const timeframes = ['1m', '5m', '15m', '1h', '4h', '1d']
  const DEFAULT_VISIBLE_BARS = 300
  const CHARTS_PER_ROW = 3
  const ROWS_VISIBLE = 2
  const ROW_BUFFER = 2 // Extra rows above and below

  // Handle interval change for specific chart
  const handleMultiChartIntervalChange = useCallback((symbol: string, interval: string) => {
    setMultiChartIntervals(prev => ({
      ...prev,
      [symbol]: interval
    }))
  }, [])

  // Fetch tickers list
  useEffect(() => {
    const fetchTickers = async () => {
      try {
        const response = await fetch('/api/tickers')
        if (!response.ok) throw new Error('Failed to fetch tickers')
        const data = await response.json()
        setTickers(data.tickers)
      } finally {
        setTickersLoading(false)
      }
    }
    fetchTickers()
  }, [])

  // Fetch candle data for single chart
  const fetchData = useCallback(async (symbol: string, interval: string) => {
    isLoadingDataRef.current = true
    setLoading(true)

    try {
      const response = await fetch(`/api/btc-futures?symbol=${symbol}&interval=${interval}&limit=500`)
      if (!response.ok) throw new Error('Failed to fetch data')

      const data: ApiResponse = await response.json()

      const candlestickData: CandlestickData<Time>[] = data.candles.map((candle) => ({
        time: candle.time as Time,
        open: candle.open,
        high: candle.high,
        low: candle.low,
        close: candle.close,
      }))

      const volumeData: HistogramData<Time>[] = data.candles.map((candle) => ({
        time: candle.time as Time,
        value: candle.volume,
        color: candle.close >= candle.open ? 'rgba(34, 197, 94, 0.5)' : 'rgba(239, 68, 68, 0.5)',
      }))

      if (candlestickSeriesRef.current && volumeSeriesRef.current && chartRef.current) {
        const chart = chartRef.current
        const candlestickSeries = candlestickSeriesRef.current
        const volumeSeries = volumeSeriesRef.current
        const timeScale = chart.timeScale()
        
        currentSymbolRef.current = symbol
        currentIntervalRef.current = interval
        
        const lastPrice = candlestickData[candlestickData.length - 1]?.close ?? 0
        let precision = 2
        let minMove = 0.01
        if (lastPrice >= 1000) {
          precision = 0
          minMove = 1
        } else if (lastPrice >= 1) {
          precision = 2
          minMove = 0.01
        } else if (lastPrice >= 0.01) {
          precision = 4
          minMove = 0.0001
        } else if (lastPrice >= 0.0001) {
          precision = 6
          minMove = 0.000001
        } else {
          precision = 8
          minMove = 0.00000001
        }
        
        candlestickSeries.applyOptions({
          priceFormat: {
            type: 'price',
            precision: precision,
            minMove: minMove,
          },
        })
        
        candlestickSeries.setData(candlestickData)
        volumeSeries.setData(volumeData)
        
        const key = `${symbol}-${interval}`
        const savedState = viewStateMapRef.current.get(key)
        
        if (savedState && savedState.logicalRange) {
          timeScale.setVisibleLogicalRange(savedState.logicalRange)
          timeScale.applyOptions({ rightOffset: savedState.rightOffset })
        } else {
          const lastIndex = candlestickData.length - 1
          const fromIndex = Math.max(0, lastIndex - DEFAULT_VISIBLE_BARS)
          timeScale.setVisibleLogicalRange({
            from: fromIndex,
            to: lastIndex
          })
          const rightOffset = Math.floor(DEFAULT_VISIBLE_BARS / 8)
          timeScale.applyOptions({ rightOffset: rightOffset })
          viewStateMapRef.current.set(key, {
            logicalRange: { from: fromIndex, to: lastIndex },
            rightOffset: rightOffset
          })
        }
        
        candlestickSeries.priceScale().applyOptions({
          autoScale: true
        })
        
        // Force chart resize after data load
        setTimeout(() => {
          if (chartRef.current && chartContainerRef.current) {
            const width = chartContainerRef.current.clientWidth
            const height = chartContainerRef.current.clientHeight
            if (width > 0 && height > 0) {
              chartRef.current.applyOptions({ width, height })
            }
          }
        }, 100)
      }
    } finally {
      setLoading(false)
      // Clear any existing timeout
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
      timeoutRef.current = setTimeout(() => {
        isLoadingDataRef.current = false
        timeoutRef.current = null
      }, 50)
    }
  }, [])

  // Initialize single chart
  useEffect(() => {
    if (pageMode !== 'single' || !chartContainerRef.current) return

    const chart = createChart(chartContainerRef.current, {
      layout: {
        background: { type: ColorType.Solid, color: 'transparent' },
        textColor: '#9ca3af',
      },
      grid: {
        vertLines: { color: 'rgba(107, 114, 128, 0.1)' },
        horzLines: { color: 'rgba(107, 114, 128, 0.1)' },
      },
      width: chartContainerRef.current.clientWidth,
      height: chartContainerRef.current.clientHeight,
      crosshair: {
        mode: 1,
        vertLine: { color: 'rgba(107, 114, 128, 0.4)', width: 1, style: 2 },
        horzLine: { color: 'rgba(107, 114, 128, 0.4)', width: 1, style: 2 },
      },
      rightPriceScale: { 
        borderColor: 'rgba(107, 114, 128, 0.3)',
        autoScale: true,
        scaleMargins: { top: 0.15, bottom: 0.15 },
      },
      timeScale: { 
        borderColor: 'rgba(107, 114, 128, 0.3)', 
        timeVisible: true, 
        secondsVisible: false,
      },
    })

    const container = chartContainerRef.current
    const style = document.createElement('style')
    style.id = 'tv-chart-hide-attribution'
    style.textContent = `
      .tv-lightweight-charts { 
        overflow: hidden !important;
      }
      [class*="tv-lightweight-charts"] a,
      [class*="tv-lightweight-charts"] svg,
      [class*="attribution"],
      a[href*="tradingview"] {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
      }
    `
    container.appendChild(style)

    const candlestickSeries = chart.addSeries(CandlestickSeries, {
      upColor: '#22c55e',
      downColor: '#ef4444',
      borderUpColor: '#22c55e',
      borderDownColor: '#ef4444',
      wickUpColor: '#22c55e',
      wickDownColor: '#ef4444',
    })

    const volumeSeries = chart.addSeries(HistogramSeries, {
      priceFormat: { type: 'volume' },
      priceScaleId: '',
    })

    volumeSeries.priceScale().applyOptions({
      scaleMargins: { top: 0.8, bottom: 0 },
    })

    chartRef.current = chart
    candlestickSeriesRef.current = candlestickSeries
    volumeSeriesRef.current = volumeSeries

    const timeScale = chart.timeScale()
    
    const saveViewHandler = (range: LogicalRange | null) => {
      if (isLoadingDataRef.current) return
      if (!currentSymbolRef.current || !currentIntervalRef.current) return
      if (!range) return
      
      const options = timeScale.options()
      const key = `${currentSymbolRef.current}-${currentIntervalRef.current}`
      viewStateMapRef.current.set(key, { 
        logicalRange: range, 
        rightOffset: options.rightOffset ?? 0 
      })
    }
    
    timeScale.subscribeVisibleLogicalRangeChange(saveViewHandler)

    // Redraw drawings when visible range changes - immediate sync with chart
    const redrawHandler = () => {
      drawOnCanvasRef.current?.()
    }
    timeScale.subscribeVisibleLogicalRangeChange(redrawHandler)

    // Update plot area on visible range change
    const updatePlotArea = () => {
      if (!chartRef.current || !chartContainerRef.current) return

      try {
        const chart = chartRef.current
        const containerWidth = chartContainerRef.current.clientWidth
        const containerHeight = chartContainerRef.current.clientHeight

        // Use the library's built-in method to get plot area dimensions
        try {
          const paneSize = chart.paneSize(0)
          // paneSize returns the full pane size, but we need the actual plot area
          // which excludes the price scale (right) and time scale (bottom)
          // For lightweight-charts, the price scale is typically on the right
          // and takes about 60-80px depending on price formatting
          
          // Get the time scale height (usually at the bottom)
          const timeScaleHeight = 25 // approximate
          
          // paneSize.width already excludes price scale in lightweight-charts v4+
          if (paneSize.width > 0 && paneSize.height > 0) {
            // The height from paneSize includes the time scale area
            // We need to subtract it for proper clipping
            plotAreaRef.current = { 
              width: paneSize.width, 
              height: paneSize.height - timeScaleHeight 
            }
          } else {
            plotAreaRef.current = { width: containerWidth - 70, height: containerHeight - 30 }
          }
        } catch {
          plotAreaRef.current = { width: containerWidth - 70, height: containerHeight - 30 }
        }
      } catch {
        // Ignore errors
      }
    }

    timeScale.subscribeVisibleLogicalRangeChange(updatePlotArea)
    
    // Track price range changes for vertical zoom/pan sync
    // Since lightweight-charts doesn't have a direct price range change subscription,
    // we use a combination of crosshair move and mouse events on the chart container
    let lastPriceRange: { from: number; to: number } | null = null
    let priceCheckRafId: number | null = null
    
    const checkPriceRangeChange = () => {
      if (!chartRef.current || !candlestickSeriesRef.current) return
      
      const ps = candlestickSeriesRef.current.priceScale()
      const currentRange = ps.getVisibleRange()
      
      if (currentRange) {
        if (lastPriceRange === null || 
            lastPriceRange.from !== currentRange.from || 
            lastPriceRange.to !== currentRange.to) {
          lastPriceRange = currentRange
          drawOnCanvasRef.current?.()
        }
      }
    }
    
    // Check price range during user interactions
    const startPriceTracking = () => {
      const track = () => {
        checkPriceRangeChange()
        priceCheckRafId = requestAnimationFrame(track)
      }
      if (priceCheckRafId === null) {
        track()
      }
    }
    
    const stopPriceTracking = () => {
      if (priceCheckRafId !== null) {
        cancelAnimationFrame(priceCheckRafId)
        priceCheckRafId = null
      }
    }
    
    // Also check on crosshair move (fires during interactions)
    chart.subscribeCrosshairMove(() => {
      checkPriceRangeChange()
    })
    
    // Track mouse/touch interactions on chart container for continuous tracking
    if (container) {
      container.addEventListener('mousedown', startPriceTracking)
      container.addEventListener('touchstart', startPriceTracking)
      container.addEventListener('wheel', startPriceTracking)
      
      document.addEventListener('mouseup', stopPriceTracking)
      document.addEventListener('touchend', stopPriceTracking)
      container.addEventListener('wheel', stopPriceTracking)
    }
    
    // Initial plot area update
    setTimeout(updatePlotArea, 100)
    
    // Force initial resize after chart is created
    setTimeout(() => {
      if (chartContainerRef.current) {
        const width = chartContainerRef.current.clientWidth
        const height = chartContainerRef.current.clientHeight
        if (width > 0 && height > 0) {
          chart.applyOptions({ width, height })
        }
      }
    }, 50)

    const handleResize = () => {
      if (chartContainerRef.current) {
        const width = chartContainerRef.current.clientWidth
        const height = chartContainerRef.current.clientHeight
        chart.applyOptions({
          width,
          height,
        })
        // Resize canvas
        if (drawingCanvasRef.current) {
          const dpr = window.devicePixelRatio || 1
          drawingCanvasRef.current.width = width * dpr
          drawingCanvasRef.current.height = height * dpr
          drawingCanvasRef.current.style.width = `${width}px`
          drawingCanvasRef.current.style.height = `${height}px`
          const ctx = drawingCanvasRef.current.getContext('2d')
          if (ctx) {
            // Reset transform before applying new scale
            ctx.setTransform(1, 0, 0, 1, 0, 0)
            ctx.scale(dpr, dpr)
          }
        }
        drawOnCanvasRef.current?.()
      }
    }

    window.addEventListener('resize', handleResize)

    // ResizeObserver for container size changes
    const resizeObserver = new ResizeObserver(() => {
      handleResize()
    })
    if (chartContainerRef.current) {
      resizeObserver.observe(chartContainerRef.current)
    }

    // Initialize canvas
    if (drawingCanvasRef.current && chartContainerRef.current) {
      const dpr = window.devicePixelRatio || 1
      const width = chartContainerRef.current.clientWidth
      const height = chartContainerRef.current.clientHeight
      drawingCanvasRef.current.width = width * dpr
      drawingCanvasRef.current.height = height * dpr
      drawingCanvasRef.current.style.width = `${width}px`
      drawingCanvasRef.current.style.height = `${height}px`
      const ctx = drawingCanvasRef.current.getContext('2d')
      if (ctx) {
        // Reset transform before applying new scale
        ctx.setTransform(1, 0, 0, 1, 0, 0)
        ctx.scale(dpr, dpr)
      }
    }

    return () => {
      // Clear any pending timeout
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
        timeoutRef.current = null
      }
      // Stop price tracking RAF
      if (priceCheckRafId !== null) {
        cancelAnimationFrame(priceCheckRafId)
      }
      // Remove event listeners
      window.removeEventListener('resize', handleResize)
      resizeObserver.disconnect()
      if (container) {
        container.removeEventListener('mousedown', startPriceTracking)
        container.removeEventListener('touchstart', startPriceTracking)
        container.removeEventListener('wheel', startPriceTracking)
      }
      document.removeEventListener('mouseup', stopPriceTracking)
      document.removeEventListener('touchend', stopPriceTracking)
      // Remove the injected style element
      const styleElement = document.getElementById('tv-chart-hide-attribution')
      if (styleElement) {
        styleElement.remove()
      }
      chart.remove()
      chartRef.current = null
      candlestickSeriesRef.current = null
      volumeSeriesRef.current = null
      drawingCanvasRef.current = null
      drawOnCanvasRef.current = null
      mousePositionRef.current = null
      currentDrawingRef.current = null
      isDrawingRef.current = false
    }
  }, [pageMode])

  // Ensure canvas is properly initialized when drawing canvas ref becomes available
  useEffect(() => {
    if (pageMode !== 'single') return
    if (!drawingCanvasRef.current || !chartContainerRef.current) return

    const dpr = window.devicePixelRatio || 1
    const width = chartContainerRef.current.clientWidth
    const height = chartContainerRef.current.clientHeight

    if (width > 0 && height > 0) {
      drawingCanvasRef.current.width = width * dpr
      drawingCanvasRef.current.height = height * dpr
      drawingCanvasRef.current.style.width = `${width}px`
      drawingCanvasRef.current.style.height = `${height}px`
      const ctx = drawingCanvasRef.current.getContext('2d')
      if (ctx) {
        ctx.setTransform(1, 0, 0, 1, 0, 0)
        ctx.scale(dpr, dpr)
      }
    }
  }, [pageMode, drawingTool])

  // Fetch data when symbol or interval changes (single chart)
  useEffect(() => {
    if (pageMode !== 'single') return
    if (chartRef.current && candlestickSeriesRef.current && volumeSeriesRef.current) {
      fetchData(selectedSymbol, selectedInterval)
    }
  }, [fetchData, selectedSymbol, selectedInterval, pageMode])

  // Redraw when symbol/interval changes
  useEffect(() => {
    drawOnCanvasRef.current?.()
  }, [selectedSymbol, selectedInterval])

  // Redraw when drawing tool changes (to show/hide preview cursor)
  useEffect(() => {
    drawOnCanvasRef.current?.()
  }, [drawingTool])

  const handleTickerClick = (symbol: string) => {
    setSelectedSymbol(symbol)
  }

  const handleIntervalChange = (interval: string) => {
    setSelectedInterval(interval)
  }

  const formatVolume = (volume: number) => {
    if (volume >= 1e9) return `${(volume / 1e9).toFixed(0)}B`
    if (volume >= 1e6) return `${(volume / 1e6).toFixed(0)}M`
    if (volume >= 1e3) return `${(volume / 1e3).toFixed(0)}K`
    return volume.toFixed(0)
  }

  const formatCount = (count: number) => {
    if (count >= 1e6) return `${(count / 1e6).toFixed(1)}M`
    if (count >= 1e3) return `${(count / 1e3).toFixed(0)}K`
    return count.toString()
  }

  const formatChange = (change: number) => {
    const sign = change >= 0 ? '+' : ''
    return `${sign}${change.toFixed(1)}`
  }

  const formatPrice = (price: number) => {
    if (price >= 1000) return price.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })
    if (price >= 1) return price.toFixed(3)
    if (price >= 0.01) return price.toFixed(4)
    return price.toFixed(5)
  }

  const calcNATR = (ticker: Ticker) => {
    if (ticker.lastPrice === 0) return '0.0'
    const range = ((ticker.highPrice - ticker.lowPrice) / ticker.lastPrice) * 100
    return range.toFixed(1)
  }

  // Drawing functions
  const generateId = () => Math.random().toString(36).substring(2, 11)

  const getDrawingsKey = (symbol: string, interval: string) => `${symbol}-${interval}`

  const getCurrentDrawings = useCallback(() => {
    const key = getDrawingsKey(currentSymbolRef.current, currentIntervalRef.current)
    return drawingsRef.current.get(key) || []
  }, [])

  const saveDrawing = useCallback((drawing: Drawing) => {
    const key = getDrawingsKey(currentSymbolRef.current, currentIntervalRef.current)
    const drawings = drawingsRef.current.get(key) || []
    drawings.push(drawing)
    drawingsRef.current.set(key, drawings)
  }, [])

  const deleteDrawing = useCallback((drawingId: string) => {
    const key = getDrawingsKey(currentSymbolRef.current, currentIntervalRef.current)
    const drawings = drawingsRef.current.get(key) || []
    const filtered = drawings.filter(d => d.id !== drawingId)
    drawingsRef.current.set(key, filtered)
    if (selectedDrawingId === drawingId) {
      setSelectedDrawingId(null)
    }
    drawOnCanvasRef.current?.()
  }, [selectedDrawingId])

  // Get the selected drawing
  const getSelectedDrawing = useCallback((): Drawing | null => {
    if (!selectedDrawingId) return null
    const drawings = getCurrentDrawings()
    return drawings.find(d => d.id === selectedDrawingId) || null
  }, [selectedDrawingId, getCurrentDrawings])

  // Get drawing settings for the settings menu
  const getSelectedDrawingSettings = useCallback((): DrawingSettings => {
    const drawing = getSelectedDrawing()
    if (!drawing) {
      return {
        color: DEFAULT_DRAWING_SETTINGS.color,
        lineWidth: DEFAULT_DRAWING_SETTINGS.lineWidth,
        lineStyle: DEFAULT_DRAWING_SETTINGS.lineStyle,
        opacity: DEFAULT_DRAWING_SETTINGS.opacity,
        locked: DEFAULT_DRAWING_SETTINGS.locked,
        visible: DEFAULT_DRAWING_SETTINGS.visible,
      }
    }
    return {
      color: drawing.color,
      lineWidth: drawing.lineWidth,
      lineStyle: drawing.lineStyle,
      opacity: drawing.opacity,
      locked: drawing.locked,
      visible: drawing.visible,
    }
  }, [getSelectedDrawing])

  // Update drawing settings
  const handleDrawingSettingsChange = useCallback((newSettings: DrawingSettings) => {
    if (!selectedDrawingId) return
    
    const key = getDrawingsKey(currentSymbolRef.current, currentIntervalRef.current)
    const drawings = drawingsRef.current.get(key) || []
    const index = drawings.findIndex(d => d.id === selectedDrawingId)
    
    if (index !== -1) {
      drawings[index] = {
        ...drawings[index],
        color: newSettings.color,
        lineWidth: newSettings.lineWidth,
        lineStyle: newSettings.lineStyle,
        opacity: newSettings.opacity,
        locked: newSettings.locked,
        visible: newSettings.visible,
      }
      drawingsRef.current.set(key, [...drawings])
      drawOnCanvasRef.current?.()
    }
  }, [selectedDrawingId])

  // Duplicate selected drawing
  const handleDuplicateDrawing = useCallback(() => {
    const drawing = getSelectedDrawing()
    if (!drawing) return

    const newDrawing: Drawing = {
      ...drawing,
      id: generateId(),
      points: drawing.points.map(p => ({
        ...p,
        logicalIndex: p.logicalIndex + 5, // Offset slightly
      })),
    }

    saveDrawing(newDrawing)
    setSelectedDrawingId(newDrawing.id)
  }, [getSelectedDrawing, saveDrawing])

  // Helper to convert price/logical to coordinates
  const priceToCoordinate = useCallback((point: DrawingPoint): { x: number; y: number } | null => {
    if (!chartRef.current || !candlestickSeriesRef.current) return null

    const chart = chartRef.current
    const series = candlestickSeriesRef.current
    const timeScale = chart.timeScale()

    const y = series.priceToCoordinate(point.price)
    // Cast number to Logical type (lightweight-charts v5 uses branded type)
    const x = timeScale.logicalToCoordinate(point.logicalIndex as unknown as Logical)

    if (y === null || x === null) return null

    return { x, y }
  }, [])

  // Calculate distance from point to line segment
  const pointToLineDistance = (px: number, py: number, x1: number, y1: number, x2: number, y2: number): number => {
    const A = px - x1
    const B = py - y1
    const C = x2 - x1
    const D = y2 - y1

    const dot = A * C + B * D
    const lenSq = C * C + D * D
    let param = -1

    if (lenSq !== 0) {
      param = dot / lenSq
    }

    let xx, yy

    if (param < 0) {
      xx = x1
      yy = y1
    } else if (param > 1) {
      xx = x2
      yy = y2
    } else {
      xx = x1 + param * C
      yy = y1 + param * D
    }

    const dx = px - xx
    const dy = py - yy

    return Math.sqrt(dx * dx + dy * dy)
  }

  // Find drawing near a point (for selection)
  const findDrawingAtPoint = useCallback((x: number, y: number, threshold: number = 10): Drawing | null => {
    const drawings = getCurrentDrawings()

    for (let i = drawings.length - 1; i >= 0; i--) {
      const drawing = drawings[i]

      // Special case for hline - horizontal line across entire chart
      if (drawing.type === 'hline' && drawing.points.length >= 1) {
        const coord = priceToCoordinate(drawing.points[0])
        if (coord && Math.abs(y - coord.y) < threshold) {
          return drawing
        }
        continue
      }

      // Special case for hray - horizontal ray from point to right edge
      if (drawing.type === 'hray' && drawing.points.length >= 1) {
        const coord = priceToCoordinate(drawing.points[0])
        if (coord && x >= coord.x - threshold && Math.abs(y - coord.y) < threshold) {
          return drawing
        }
        continue
      }

      // Special case for rectangle - check if point is near edges only (not inside)
      if (drawing.type === 'rectangle' && drawing.points.length >= 2) {
        const p1 = priceToCoordinate(drawing.points[0])
        const p2 = priceToCoordinate(drawing.points[1])
        if (p1 && p2) {
          const rectX = Math.min(p1.x, p2.x)
          const rectY = Math.min(p1.y, p2.y)
          const rectW = Math.abs(p2.x - p1.x)
          const rectH = Math.abs(p2.y - p1.y)

          // Check if near any edge (not inside)
          const nearTop = Math.abs(y - rectY) < threshold && x >= rectX - threshold && x <= rectX + rectW + threshold
          const nearBottom = Math.abs(y - (rectY + rectH)) < threshold && x >= rectX - threshold && x <= rectX + rectW + threshold
          const nearLeft = Math.abs(x - rectX) < threshold && y >= rectY - threshold && y <= rectY + rectH + threshold
          const nearRight = Math.abs(x - (rectX + rectW)) < threshold && y >= rectY - threshold && y <= rectY + rectH + threshold

          if (nearTop || nearBottom || nearLeft || nearRight) {
            return drawing
          }
        }
        continue
      }

      // Special case for fibonacci - check if near the anchor line or any fib line
      if (drawing.type === 'fibonacci' && drawing.points.length >= 2) {
        const p1 = priceToCoordinate(drawing.points[0])
        const p2 = priceToCoordinate(drawing.points[1])
        if (p1 && p2) {
          const minY = Math.min(p1.y, p2.y)
          const maxY = Math.max(p1.y, p2.y)
          const minX = Math.min(p1.x, p2.x)
          const maxX = Math.max(p1.x, p2.x)

          // Check if near the main trend line
          const dist = pointToLineDistance(x, y, p1.x, p1.y, p2.x, p2.y)
          if (dist < threshold) {
            return drawing
          }

          // Check if near any fibonacci horizontal line
          const fibLevels = [0, 0.236, 0.382, 0.5, 0.618, 0.786, 1]
          for (const level of fibLevels) {
            const lineY = p1.y + (p2.y - p1.y) * level
            if (Math.abs(y - lineY) < threshold && x >= minX - threshold && x <= maxX + threshold) {
              return drawing
            }
          }
        }
        continue
      }

      // For other drawings (pencil, trendline, trendray), check if point is near any segment
      for (let j = 0; j < drawing.points.length - 1; j++) {
        const p1 = priceToCoordinate(drawing.points[j])
        const p2 = priceToCoordinate(drawing.points[j + 1])
        if (p1 && p2) {
          const dist = pointToLineDistance(x, y, p1.x, p1.y, p2.x, p2.y)
          if (dist < threshold) {
            return drawing
          }
        }
      }
    }

    return null
  }, [getCurrentDrawings, priceToCoordinate])

  // Find handle at point (for resizing/editing drawings)
  // Returns handle index:
  // - For rectangle: 0=top-left, 1=top-right, 2=bottom-left, 3=bottom-right
  // - For other 2-point tools: 0=first point, 1=second point
  // - For hline/hray: 0=the single point
  const findHandleAtPoint = useCallback((x: number, y: number, drawingId: string, threshold: number = 10): number | null => {
    const drawings = getCurrentDrawings()
    const drawing = drawings.find(d => d.id === drawingId)
    if (!drawing) return null

    // Special case for rectangle - 4 corner handles
    if (drawing.type === 'rectangle' && drawing.points.length >= 2) {
      const p1 = priceToCoordinate(drawing.points[0])
      const p2 = priceToCoordinate(drawing.points[1])
      if (p1 && p2) {
        const left = Math.min(p1.x, p2.x)
        const right = Math.max(p1.x, p2.x)
        const top = Math.min(p1.y, p2.y)
        const bottom = Math.max(p1.y, p2.y)

        // Check 4 corners
        const corners = [
          { x: left, y: top },      // 0: top-left
          { x: right, y: top },     // 1: top-right
          { x: left, y: bottom },   // 2: bottom-left
          { x: right, y: bottom },  // 3: bottom-right
        ]

        for (let i = 0; i < corners.length; i++) {
          const dist = Math.sqrt((x - corners[i].x) ** 2 + (y - corners[i].y) ** 2)
          if (dist < threshold) {
            return i
          }
        }
      }
      return null
    }

    // For other two-point tools (trendline, trendray, fibonacci), check both endpoints
    if (drawing.points.length >= 2) {
      for (let i = 0; i < 2; i++) {
        const coord = priceToCoordinate(drawing.points[i])
        if (coord) {
          const dist = Math.sqrt((x - coord.x) ** 2 + (y - coord.y) ** 2)
          if (dist < threshold) {
            return i
          }
        }
      }
    }

    // For hline and hray, check the single point
    if (drawing.points.length === 1 && (drawing.type === 'hline' || drawing.type === 'hray')) {
      const coord = priceToCoordinate(drawing.points[0])
      if (coord) {
        const dist = Math.sqrt((x - coord.x) ** 2 + (y - coord.y) ** 2)
        if (dist < threshold) {
          return 0
        }
      }
    }

    return null
  }, [getCurrentDrawings, priceToCoordinate])

  // Update a drawing in the drawings array
  const updateDrawing = useCallback((drawingId: string, updates: Partial<Drawing>) => {
    const key = getDrawingsKey(currentSymbolRef.current, currentIntervalRef.current)
    const drawings = drawingsRef.current.get(key) || []
    const index = drawings.findIndex(d => d.id === drawingId)
    if (index !== -1) {
      drawings[index] = { ...drawings[index], ...updates }
      drawingsRef.current.set(key, [...drawings])
      drawOnCanvasRef.current?.()
    }
  }, [])

  // Douglas-Peucker algorithm for point simplification
  const simplifyPoints = (points: DrawingPoint[], tolerance: number = 0.0001): DrawingPoint[] => {
    if (points.length <= 2) return points

    // Find the point with the maximum distance from line between first and last
    let maxDist = 0
    let maxIndex = 0

    const first = points[0]
    const last = points[points.length - 1]

    // Use logicalIndex for distance calculation
    const firstX = first.logicalIndex
    const lastX = last.logicalIndex

    for (let i = 1; i < points.length - 1; i++) {
      const p = points[i]
      const px = p.logicalIndex
      
      // Calculate distance from point to line segment
      const dx = lastX - firstX
      const dy = last.price - first.price
      const len = dx * dx + dy * dy

      let dist: number
      if (len === 0) {
        dist = Math.sqrt((px - firstX) ** 2 + (p.price - first.price) ** 2)
      } else {
        const t = Math.max(0, Math.min(1, ((px - firstX) * dx + (p.price - first.price) * dy) / len))
        const projX = firstX + t * dx
        const projY = first.price + t * dy
        dist = Math.sqrt((px - projX) ** 2 + (p.price - projY) ** 2)
      }

      if (dist > maxDist) {
        maxDist = dist
        maxIndex = i
      }
    }

    // If max distance is greater than tolerance, recursively simplify
    if (maxDist > tolerance) {
      const left = simplifyPoints(points.slice(0, maxIndex + 1), tolerance)
      const right = simplifyPoints(points.slice(maxIndex), tolerance)
      return [...left.slice(0, -1), ...right]
    }

    return [first, last]
  }

  // Draw on canvas - direct synchronous drawing for proper sync with chart
  const drawOnCanvas = useCallback(() => {
    const canvas = drawingCanvasRef.current
    const ctx = canvas?.getContext('2d')
    if (!canvas || !ctx || !chartContainerRef.current) return

    const dpr = window.devicePixelRatio || 1
    let plotArea = plotAreaRef.current

    // Fallback if plotArea is not initialized
    if (plotArea.width <= 0 || plotArea.height <= 0) {
      const containerWidth = chartContainerRef.current.clientWidth
      const containerHeight = chartContainerRef.current.clientHeight
      plotArea = {
        width: containerWidth - 70, // typical price scale width
        height: containerHeight - 30 // typical time scale height
      }
    }

    // Clear canvas (accounting for DPR)
    ctx.setTransform(1, 0, 0, 1, 0, 0)
    ctx.clearRect(0, 0, canvas.width, canvas.height)
    ctx.scale(dpr, dpr)

    // Save context and apply clipping to plot area
    ctx.save()
    ctx.beginPath()
    ctx.rect(0, 0, plotArea.width, plotArea.height)
    ctx.clip()

    const drawings = getCurrentDrawings()
    const currentDrawing = currentDrawingRef.current

    // Draw all saved drawings
    drawings.forEach(drawing => {
      drawDrawing(ctx, drawing)
    })

    // Draw current drawing in progress
    if (currentDrawing) {
      drawDrawing(ctx, currentDrawing)
    }

    // Draw temporary ruler (middle mouse button)
    if (tempRulerRef.current) {
      drawDrawing(ctx, tempRulerRef.current)
    }

    // Restore context (remove clipping)
    ctx.restore()

    // Draw preview when tool is selected but not yet drawing (outside clipped area is ok)
    const mousePos = mousePositionRef.current
    if (drawingTool && !isDrawingRef.current && mousePos) {
      drawPreview(ctx, mousePos)
    }
  }, [getCurrentDrawings, drawingTool, selectedDrawingId])

  // Draw preview based on selected tool
  const drawPreview = (ctx: CanvasRenderingContext2D, mousePos: { x: number; y: number; price: number; time: number }) => {
    const plotArea = plotAreaRef.current

    if (drawingTool === 'hray') {
      // Preview horizontal ray starting from cursor to the right
      ctx.globalAlpha = 0.6
      ctx.setLineDash([5, 5])
      ctx.beginPath()
      ctx.moveTo(mousePos.x, mousePos.y)
      ctx.lineTo(plotArea.width, mousePos.y)
      ctx.strokeStyle = '#f59e0b'
      ctx.lineWidth = 2
      ctx.stroke()
      // Show price tooltip
      ctx.setLineDash([])
      ctx.fillStyle = '#f59e0b'
      ctx.font = '10px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
      ctx.textAlign = 'left'
      ctx.fillText(mousePos.price.toFixed(2), mousePos.x + 5, mousePos.y - 5)
      ctx.globalAlpha = 1
      return
    }

    if (drawingTool === 'hline') {
      // Preview horizontal line across entire chart
      ctx.globalAlpha = 0.6
      ctx.setLineDash([5, 5])
      ctx.beginPath()
      ctx.moveTo(0, mousePos.y)
      ctx.lineTo(plotArea.width, mousePos.y)
      ctx.strokeStyle = '#f59e0b'
      ctx.lineWidth = 2
      ctx.stroke()
      // Show price tooltip
      ctx.setLineDash([])
      ctx.fillStyle = '#f59e0b'
      ctx.font = '10px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
      ctx.textAlign = 'left'
      ctx.fillText(mousePos.price.toFixed(2), 5, mousePos.y - 5)
      ctx.globalAlpha = 1
      return
    }

    if (drawingTool === 'trendline') {
      // Preview crosshair for trendline
      ctx.globalAlpha = 0.8
      ctx.setLineDash([])
      // Draw crosshair
      ctx.beginPath()
      ctx.moveTo(mousePos.x - 10, mousePos.y)
      ctx.lineTo(mousePos.x + 10, mousePos.y)
      ctx.moveTo(mousePos.x, mousePos.y - 10)
      ctx.lineTo(mousePos.x, mousePos.y + 10)
      ctx.strokeStyle = '#f59e0b'
      ctx.lineWidth = 1
      ctx.stroke()
      // Draw center dot
      ctx.beginPath()
      ctx.arc(mousePos.x, mousePos.y, 3, 0, Math.PI * 2)
      ctx.fillStyle = '#f59e0b'
      ctx.fill()
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 1
      ctx.stroke()
      ctx.globalAlpha = 1
      return
    }

    if (drawingTool === 'trendray') {
      // Preview crosshair for trendray (same as trendline)
      ctx.globalAlpha = 0.8
      ctx.setLineDash([])
      // Draw crosshair
      ctx.beginPath()
      ctx.moveTo(mousePos.x - 10, mousePos.y)
      ctx.lineTo(mousePos.x + 10, mousePos.y)
      ctx.moveTo(mousePos.x, mousePos.y - 10)
      ctx.lineTo(mousePos.x, mousePos.y + 10)
      ctx.strokeStyle = '#f59e0b'
      ctx.lineWidth = 1
      ctx.stroke()
      // Draw center dot
      ctx.beginPath()
      ctx.arc(mousePos.x, mousePos.y, 3, 0, Math.PI * 2)
      ctx.fillStyle = '#f59e0b'
      ctx.fill()
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 1
      ctx.stroke()
      ctx.globalAlpha = 1
      return
    }

    if (drawingTool === 'rectangle') {
      // Preview crosshair for rectangle (same style as trendline)
      ctx.globalAlpha = 0.8
      ctx.setLineDash([])
      // Draw crosshair
      ctx.beginPath()
      ctx.moveTo(mousePos.x - 10, mousePos.y)
      ctx.lineTo(mousePos.x + 10, mousePos.y)
      ctx.moveTo(mousePos.x, mousePos.y - 10)
      ctx.lineTo(mousePos.x, mousePos.y + 10)
      ctx.strokeStyle = '#f59e0b'
      ctx.lineWidth = 1
      ctx.stroke()
      // Draw center dot
      ctx.beginPath()
      ctx.arc(mousePos.x, mousePos.y, 3, 0, Math.PI * 2)
      ctx.fillStyle = '#f59e0b'
      ctx.fill()
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 1
      ctx.stroke()
      ctx.globalAlpha = 1
      return
    }

    if (drawingTool === 'fibonacci') {
      // Preview crosshair for fibonacci (same style as trendline)
      ctx.globalAlpha = 0.8
      ctx.setLineDash([])
      // Draw crosshair
      ctx.beginPath()
      ctx.moveTo(mousePos.x - 10, mousePos.y)
      ctx.lineTo(mousePos.x + 10, mousePos.y)
      ctx.moveTo(mousePos.x, mousePos.y - 10)
      ctx.lineTo(mousePos.x, mousePos.y + 10)
      ctx.strokeStyle = '#f59e0b'
      ctx.lineWidth = 1
      ctx.stroke()
      // Draw center dot
      ctx.beginPath()
      ctx.arc(mousePos.x, mousePos.y, 3, 0, Math.PI * 2)
      ctx.fillStyle = '#f59e0b'
      ctx.fill()
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 1
      ctx.stroke()
      // Show price tooltip
      ctx.fillStyle = '#f59e0b'
      ctx.font = '10px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
      ctx.textAlign = 'left'
      ctx.fillText(mousePos.price.toFixed(2), mousePos.x + 12, mousePos.y - 8)
      ctx.globalAlpha = 1
      return
    }

    if (drawingTool === 'ruler') {
      // Preview crosshair for ruler
      ctx.globalAlpha = 0.8
      ctx.setLineDash([])
      ctx.strokeStyle = '#06b6d4'
      ctx.lineWidth = 1
      // Draw crosshair
      ctx.beginPath()
      ctx.moveTo(mousePos.x - 10, mousePos.y)
      ctx.lineTo(mousePos.x + 10, mousePos.y)
      ctx.moveTo(mousePos.x, mousePos.y - 10)
      ctx.lineTo(mousePos.x, mousePos.y + 10)
      ctx.stroke()
      // Draw center dot
      ctx.beginPath()
      ctx.arc(mousePos.x, mousePos.y, 3, 0, Math.PI * 2)
      ctx.fillStyle = '#06b6d4'
      ctx.fill()
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 1
      ctx.stroke()
      // Show price tooltip
      ctx.fillStyle = '#06b6d4'
      ctx.font = '10px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
      ctx.textAlign = 'left'
      ctx.fillText(mousePos.price.toFixed(2), mousePos.x + 12, mousePos.y - 8)
      ctx.globalAlpha = 1
      return
    }

    if (drawingTool !== 'pencil') return

    ctx.globalAlpha = 0.8
    ctx.setLineDash([])
    // Draw crosshair
    ctx.beginPath()
    ctx.moveTo(mousePos.x - 10, mousePos.y)
    ctx.lineTo(mousePos.x + 10, mousePos.y)
    ctx.moveTo(mousePos.x, mousePos.y - 10)
    ctx.lineTo(mousePos.x, mousePos.y + 10)
    ctx.strokeStyle = '#f59e0b'
    ctx.lineWidth = 1
    ctx.stroke()
    // Draw center dot
    ctx.beginPath()
    ctx.arc(mousePos.x, mousePos.y, 3, 0, Math.PI * 2)
    ctx.fillStyle = '#f59e0b'
    ctx.fill()
    ctx.strokeStyle = '#ffffff'
    ctx.lineWidth = 1
    ctx.stroke()
    // Show price tooltip
    ctx.fillStyle = '#f59e0b'
    ctx.font = '10px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
    ctx.textAlign = 'left'
    ctx.fillText(mousePos.price.toFixed(2), mousePos.x + 12, mousePos.y - 8)

    ctx.setLineDash([])
    ctx.globalAlpha = 1
  }

  // Keep ref updated
  useEffect(() => {
    drawOnCanvasRef.current = drawOnCanvas
  }, [drawOnCanvas])

  const drawDrawing = (ctx: CanvasRenderingContext2D, drawing: Drawing) => {
    // Skip invisible drawings
    if (drawing.visible === false) return

    ctx.strokeStyle = drawing.color
    ctx.fillStyle = drawing.color
    ctx.lineWidth = drawing.lineWidth || 2
    ctx.lineCap = 'round'
    ctx.lineJoin = 'round'
    ctx.globalAlpha = drawing.opacity ?? 1
    ctx.font = '11px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'

    // Apply line style
    if (drawing.lineStyle === 'dashed') {
      ctx.setLineDash([10, 5])
    } else if (drawing.lineStyle === 'dotted') {
      ctx.setLineDash([2, 4])
    } else {
      ctx.setLineDash([])
    }

    if (drawing.type === 'pencil') {
      drawPencil(ctx, drawing)
    } else if (drawing.type === 'hray') {
      drawHray(ctx, drawing)
    } else if (drawing.type === 'hline') {
      drawHline(ctx, drawing)
    } else if (drawing.type === 'trendline') {
      drawTrendline(ctx, drawing)
    } else if (drawing.type === 'trendray') {
      drawTrendray(ctx, drawing)
    } else if (drawing.type === 'rectangle') {
      drawRectangle(ctx, drawing)
    } else if (drawing.type === 'fibonacci') {
      drawFibonacci(ctx, drawing)
    } else if (drawing.type === 'ruler') {
      drawRuler(ctx, drawing)
    }

    // Reset context state
    ctx.globalAlpha = 1
    ctx.setLineDash([])
  }

  const drawTrendline = (ctx: CanvasRenderingContext2D, drawing: Drawing) => {
    if (drawing.points.length < 2) return

    const coord1 = priceToCoordinate(drawing.points[0])
    const coord2 = priceToCoordinate(drawing.points[1])
    if (!coord1 || !coord2) return

    // Draw line segment between two points only (not extended)
    ctx.beginPath()
    ctx.moveTo(coord1.x, coord1.y)
    ctx.lineTo(coord2.x, coord2.y)
    ctx.stroke()

    // Draw selection handles if this drawing is selected
    if (drawing.id === selectedDrawingId) {
      ctx.fillStyle = drawing.color
      // Start point handle
      ctx.beginPath()
      ctx.arc(coord1.x, coord1.y, 5, 0, Math.PI * 2)
      ctx.fill()
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 1.5
      ctx.stroke()
      // End point handle
      ctx.beginPath()
      ctx.arc(coord2.x, coord2.y, 5, 0, Math.PI * 2)
      ctx.fill()
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 1.5
      ctx.stroke()
    }
  }

  const drawTrendray = (ctx: CanvasRenderingContext2D, drawing: Drawing) => {
    if (drawing.points.length < 2) return

    const coord1 = priceToCoordinate(drawing.points[0])
    const coord2 = priceToCoordinate(drawing.points[1])
    if (!coord1 || !coord2) return

    const plotArea = plotAreaRef.current

    // Calculate direction and extend line to edges
    const dx = coord2.x - coord1.x
    const dy = coord2.y - coord1.y

    // Extend line from first point through second point to chart edges
    let startX = coord1.x
    let startY = coord1.y
    let endX = coord2.x
    let endY = coord2.y

    if (dx !== 0) {
      // Calculate t values for intersections with plot area edges
      const tLeft = -coord1.x / dx
      const tRight = (plotArea.width - coord1.x) / dx
      
      // Find the direction (which way the ray goes from point 1 through point 2)
      if (dx > 0) {
        // Ray goes right, extend to right edge
        const t = tRight
        endX = plotArea.width
        endY = coord1.y + t * dy
      } else {
        // Ray goes left, extend to left edge
        const t = tLeft
        endX = 0
        endY = coord1.y + t * dy
      }
    }

    // Draw the trend ray (extended line from point 1 through point 2 to edge)
    ctx.beginPath()
    ctx.moveTo(startX, startY)
    ctx.lineTo(endX, endY)
    ctx.stroke()

    // Draw selection handles if this drawing is selected
    if (drawing.id === selectedDrawingId) {
      ctx.fillStyle = drawing.color
      // Start point handle (the anchor point)
      ctx.beginPath()
      ctx.arc(coord1.x, coord1.y, 5, 0, Math.PI * 2)
      ctx.fill()
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 1.5
      ctx.stroke()
      // End point handle (direction control)
      ctx.beginPath()
      ctx.arc(coord2.x, coord2.y, 5, 0, Math.PI * 2)
      ctx.fill()
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 1.5
      ctx.stroke()
    }
  }

  const drawRectangle = (ctx: CanvasRenderingContext2D, drawing: Drawing) => {
    if (drawing.points.length < 2) return

    const coord1 = priceToCoordinate(drawing.points[0])
    const coord2 = priceToCoordinate(drawing.points[1])
    if (!coord1 || !coord2) return

    // Calculate rectangle bounds
    const x = Math.min(coord1.x, coord2.x)
    const y = Math.min(coord1.y, coord2.y)
    const width = Math.abs(coord2.x - coord1.x)
    const height = Math.abs(coord2.y - coord1.y)

    // Draw filled rectangle with transparency
    ctx.fillStyle = drawing.color + '20' // 20 = ~12% opacity
    ctx.fillRect(x, y, width, height)

    // Draw rectangle border
    ctx.strokeStyle = drawing.color
    ctx.lineWidth = 2
    ctx.strokeRect(x, y, width, height)

    // Draw selection handles if this drawing is selected
    if (drawing.id === selectedDrawingId) {
      ctx.fillStyle = drawing.color
      const handleSize = 5
      // Four corner handles
      const handles = [
        { x: x, y: y },
        { x: x + width, y: y },
        { x: x, y: y + height },
        { x: x + width, y: y + height },
      ]
      handles.forEach(h => {
        ctx.beginPath()
        ctx.arc(h.x, h.y, handleSize, 0, Math.PI * 2)
        ctx.fill()
        ctx.strokeStyle = '#ffffff'
        ctx.lineWidth = 1.5
        ctx.stroke()
      })
    }
  }

  const drawFibonacci = (ctx: CanvasRenderingContext2D, drawing: Drawing) => {
    if (drawing.points.length < 1) return

    const coord1 = priceToCoordinate(drawing.points[0])
    if (!coord1) return

    const plotArea = plotAreaRef.current
    const price1 = drawing.points[0].price

    // If only one point, just show the starting point
    if (drawing.points.length === 1) {
      // Draw a small circle at the starting point
      ctx.beginPath()
      ctx.arc(coord1.x, coord1.y, 4, 0, Math.PI * 2)
      ctx.fillStyle = drawing.color
      ctx.fill()
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 1
      ctx.stroke()
      return
    }

    // Two points - draw full fibonacci levels
    const coord2 = priceToCoordinate(drawing.points[1])
    if (!coord2) return

    const price2 = drawing.points[1].price

    // Fibonacci levels
    const fibLevels = [
      { level: 0, label: '0' },
      { level: 0.236, label: '0.236' },
      { level: 0.382, label: '0.382' },
      { level: 0.5, label: '0.5' },
      { level: 0.618, label: '0.618' },
      { level: 0.786, label: '0.786' },
      { level: 1, label: '1' },
    ]

    // Calculate price range
    const priceRange = price2 - price1

    // Draw the main trend line
    ctx.beginPath()
    ctx.moveTo(coord1.x, coord1.y)
    ctx.lineTo(coord2.x, coord2.y)
    ctx.strokeStyle = drawing.color
    ctx.lineWidth = 1
    ctx.setLineDash([4, 4])
    ctx.stroke()
    ctx.setLineDash([])

    // Draw Fibonacci horizontal lines
    fibLevels.forEach(({ level, label }) => {
      const price = price1 + priceRange * level
      const y = coord1.y + (coord2.y - coord1.y) * level

      // Draw horizontal line between the two X coordinates
      ctx.beginPath()
      ctx.moveTo(Math.min(coord1.x, coord2.x), y)
      ctx.lineTo(Math.max(coord1.x, coord2.x), y)
      ctx.strokeStyle = drawing.color
      ctx.lineWidth = 1
      ctx.globalAlpha = level === 0 || level === 1 ? 0.8 : 0.5
      ctx.stroke()
      ctx.globalAlpha = 1

      // Draw level label at the right edge of the line
      ctx.fillStyle = drawing.color
      ctx.font = '10px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
      ctx.textAlign = 'left'
      const labelX = Math.max(coord1.x, coord2.x) + 5
      ctx.fillText(`${label} (${price.toFixed(2)})`, labelX, y + 3)
    })

    // Draw selection handles if this drawing is selected
    if (drawing.id === selectedDrawingId) {
      ctx.fillStyle = drawing.color
      // Start point handle
      ctx.beginPath()
      ctx.arc(coord1.x, coord1.y, 5, 0, Math.PI * 2)
      ctx.fill()
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 1.5
      ctx.stroke()
      // End point handle
      ctx.beginPath()
      ctx.arc(coord2.x, coord2.y, 5, 0, Math.PI * 2)
      ctx.fill()
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 1.5
      ctx.stroke()
    }
  }

  const drawRuler = (ctx: CanvasRenderingContext2D, drawing: Drawing) => {
    if (drawing.points.length < 1) return

    const coord1 = priceToCoordinate(drawing.points[0])
    if (!coord1) return

    const price1 = drawing.points[0].price
    const logical1 = drawing.points[0].logicalIndex
    const time1 = drawing.points[0].time

    // If only one point, just show the starting point
    if (drawing.points.length === 1) {
      ctx.beginPath()
      ctx.arc(coord1.x, coord1.y, 4, 0, Math.PI * 2)
      ctx.fillStyle = drawing.color
      ctx.fill()
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 1
      ctx.stroke()
      return
    }

    // Two points - draw ruler with measurements
    const coord2 = priceToCoordinate(drawing.points[1])
    if (!coord2) return

    const price2 = drawing.points[1].price
    const logical2 = drawing.points[1].logicalIndex
    const time2 = drawing.points[1].time

    // Calculate measurements
    const priceDiff = price2 - price1
    const pricePercent = ((priceDiff / price1) * 100)
    const barsDiff = Math.abs(logical2 - logical1)
    
    // Calculate time difference
    const timeDiff = Math.abs(time2 - time1)
    const hours = Math.floor(timeDiff / 3600)
    const minutes = Math.floor((timeDiff % 3600) / 60)
    const seconds = Math.floor(timeDiff % 60)
    let timeStr = ''
    if (hours > 0) {
      timeStr = `${hours}h ${minutes}m`
    } else if (minutes > 0) {
      timeStr = `${minutes}m ${seconds}s`
    } else {
      timeStr = `${seconds}s`
    }
    
    // Calculate angle
    const dx = coord2.x - coord1.x
    const dy = coord2.y - coord1.y
    const angle = Math.atan2(dy, dx) * (180 / Math.PI)
    
    // Calculate pixel distance
    const pixelDistance = Math.sqrt(dx * dx + dy * dy)

    // Draw the main line
    ctx.beginPath()
    ctx.moveTo(coord1.x, coord1.y)
    ctx.lineTo(coord2.x, coord2.y)
    ctx.strokeStyle = drawing.color
    ctx.lineWidth = 2
    ctx.stroke()

    // Draw end points
    ctx.fillStyle = drawing.color
    ctx.beginPath()
    ctx.arc(coord1.x, coord1.y, 4, 0, Math.PI * 2)
    ctx.fill()
    ctx.strokeStyle = '#ffffff'
    ctx.lineWidth = 1.5
    ctx.stroke()
    
    ctx.beginPath()
    ctx.arc(coord2.x, coord2.y, 4, 0, Math.PI * 2)
    ctx.fill()
    ctx.strokeStyle = '#ffffff'
    ctx.lineWidth = 1.5
    ctx.stroke()

    // Calculate label position (middle of the line, offset above)
    const midX = (coord1.x + coord2.x) / 2
    const midY = (coord1.y + coord2.y) / 2
    const labelOffsetY = dy >= 0 ? -15 : 15

    // Draw info box background
    const boxPadding = 6
    const lineHeight = 14
    const lines = [
      `${priceDiff >= 0 ? '+' : ''}${priceDiff.toFixed(2)} (${pricePercent >= 0 ? '+' : ''}${pricePercent.toFixed(2)}%)`,
      `Bars: ${Math.round(barsDiff)} | Time: ${timeStr}`,
      `Angle: ${angle.toFixed(1)}°`
    ]
    
    ctx.font = '11px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
    const maxWidth = Math.max(...lines.map(l => ctx.measureText(l).width))
    const boxWidth = maxWidth + boxPadding * 2
    const boxHeight = lines.length * lineHeight + boxPadding * 2
    const boxX = midX - boxWidth / 2
    const boxY = midY + labelOffsetY - boxHeight / 2

    // Draw box background
    ctx.fillStyle = 'rgba(0, 0, 0, 0.8)'
    ctx.beginPath()
    ctx.roundRect(boxX, boxY, boxWidth, boxHeight, 4)
    ctx.fill()
    
    // Draw box border
    ctx.strokeStyle = drawing.color
    ctx.lineWidth = 1
    ctx.stroke()

    // Draw text
    ctx.fillStyle = '#ffffff'
    ctx.textAlign = 'center'
    lines.forEach((line, i) => {
      ctx.fillText(line, midX, boxY + boxPadding + lineHeight * (i + 1) - 3)
    })

    // Draw selection handles if this drawing is selected
    if (drawing.id === selectedDrawingId) {
      ctx.fillStyle = drawing.color
      // Start point handle (larger)
      ctx.beginPath()
      ctx.arc(coord1.x, coord1.y, 6, 0, Math.PI * 2)
      ctx.fill()
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 2
      ctx.stroke()
      // End point handle
      ctx.beginPath()
      ctx.arc(coord2.x, coord2.y, 6, 0, Math.PI * 2)
      ctx.fill()
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 2
      ctx.stroke()
    }
  }

  const drawHline = (ctx: CanvasRenderingContext2D, drawing: Drawing) => {
    if (drawing.points.length < 1) return

    const coord = priceToCoordinate(drawing.points[0])
    if (!coord) return

    const plotArea = plotAreaRef.current
    const y = coord.y

    // Draw horizontal line across entire plot area
    ctx.beginPath()
    ctx.moveTo(0, y)
    ctx.lineTo(plotArea.width, y)
    ctx.stroke()

    // Draw selection handle if this drawing is selected
    if (drawing.id === selectedDrawingId) {
      ctx.fillStyle = drawing.color
      ctx.beginPath()
      ctx.arc(plotArea.width - 10, y, 5, 0, Math.PI * 2)
      ctx.fill()
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 1.5
      ctx.stroke()
    }
  }

  const drawHray = (ctx: CanvasRenderingContext2D, drawing: Drawing) => {
    if (drawing.points.length < 1) return

    const coord = priceToCoordinate(drawing.points[0])
    if (!coord) return

    const plotArea = plotAreaRef.current
    const y = coord.y
    const startX = coord.x

    // Draw horizontal ray starting from click point to the right
    ctx.beginPath()
    ctx.moveTo(startX, y)
    ctx.lineTo(plotArea.width, y)
    ctx.stroke()

    // Draw selection handle if this drawing is selected
    if (drawing.id === selectedDrawingId) {
      ctx.fillStyle = drawing.color
      ctx.beginPath()
      ctx.arc(startX, y, 5, 0, Math.PI * 2)
      ctx.fill()
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 1.5
      ctx.stroke()
    }
  }

  const drawPencil = (ctx: CanvasRenderingContext2D, drawing: Drawing) => {
    if (drawing.points.length < 2) return

    const coords: { x: number; y: number }[] = []
    for (let i = 0; i < drawing.points.length; i++) {
      const coord = priceToCoordinate(drawing.points[i])
      if (coord) {
        coords.push(coord)
      }
    }

    if (coords.length < 2) return

    ctx.beginPath()
    ctx.moveTo(coords[0].x, coords[0].y)

    // Use smooth bezier curves for natural drawing
    if (coords.length === 2) {
      ctx.lineTo(coords[1].x, coords[1].y)
    } else {
      // Catmull-Rom to Bezier conversion for smooth curves
      for (let i = 0; i < coords.length - 1; i++) {
        const p0 = coords[Math.max(0, i - 1)]
        const p1 = coords[i]
        const p2 = coords[Math.min(coords.length - 1, i + 1)]
        const p3 = coords[Math.min(coords.length - 1, i + 2)]

        // Calculate control points for smooth curve
        const tension = 0.3
        const cp1x = p1.x + (p2.x - p0.x) * tension
        const cp1y = p1.y + (p2.y - p0.y) * tension
        const cp2x = p2.x - (p3.x - p1.x) * tension
        const cp2y = p2.y - (p3.y - p1.y) * tension

        ctx.bezierCurveTo(cp1x, cp1y, cp2x, cp2y, p2.x, p2.y)
      }
    }

    ctx.stroke()

    // Draw selection handles if this drawing is selected
    if (drawing.id === selectedDrawingId) {
      ctx.strokeStyle = '#ffffff'
      ctx.lineWidth = 1
      ctx.setLineDash([3, 3])

      // Draw bounding box approximation
      const minX = Math.min(...coords.map(c => c.x)) - 5
      const maxX = Math.max(...coords.map(c => c.x)) + 5
      const minY = Math.min(...coords.map(c => c.y)) - 5
      const maxY = Math.max(...coords.map(c => c.y)) + 5

      ctx.strokeRect(minX, minY, maxX - minX, maxY - minY)
      ctx.setLineDash([])

      // Draw resize handles
      ctx.fillStyle = drawing.color
      const handleSize = 6
      const handles = [
        { x: minX, y: minY },
        { x: maxX, y: minY },
        { x: minX, y: maxY },
        { x: maxX, y: maxY },
      ]
      handles.forEach(h => {
        ctx.beginPath()
        ctx.arc(h.x, h.y, handleSize / 2, 0, Math.PI * 2)
        ctx.fill()
        ctx.strokeStyle = '#ffffff'
        ctx.lineWidth = 1.5
        ctx.stroke()
      })
    }
  }

  // Keyboard event handler for delete
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.key === 'Delete' || e.key === 'Backspace') && selectedDrawingId) {
        e.preventDefault()
        deleteDrawing(selectedDrawingId)
      }
      if (e.key === 'Escape') {
        setSelectedDrawingId(null)
        drawOnCanvasRef.current?.()
      }
    }

    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [selectedDrawingId, deleteDrawing])

  // Mouse event handlers
  const handleCanvasMouseDown = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    // If no tool selected, handle selection and dragging
    if (!drawingTool) {
      // First check if clicking on a handle of selected drawing
      if (selectedDrawingId) {
        const handleIndex = findHandleAtPoint(x, y, selectedDrawingId)
        if (handleIndex !== null) {
          // Start dragging handle
          const drawings = getCurrentDrawings()
          const drawing = drawings.find(d => d.id === selectedDrawingId)
          if (drawing) {
            isDraggingRef.current = true
            dragHandleRef.current = { drawingId: selectedDrawingId, handleIndex }
            dragStartRef.current = { x, y, drawing: JSON.parse(JSON.stringify(drawing)) }
            return
          }
        }
      }

      // Check for drawing selection
      const foundDrawing = findDrawingAtPoint(x, y)
      if (foundDrawing) {
        setSelectedDrawingId(foundDrawing.id)
        drawOnCanvasRef.current?.()
        // Start dragging the entire drawing
        isDraggingRef.current = true
        dragStartRef.current = { x, y, drawing: JSON.parse(JSON.stringify(foundDrawing)) }
        dragHandleRef.current = null
      } else {
        setSelectedDrawingId(null)
        drawOnCanvasRef.current?.()
      }
      return
    }

    if (!chartRef.current) return

    const point = coordinateToPrice(x, y)
    if (!point) return

    isDrawingRef.current = true
    setSelectedDrawingId(null) // Deselect when starting new drawing

    const drawing: Drawing = {
      id: generateId(),
      type: drawingTool as DrawingType,
      symbol: currentSymbolRef.current,
      interval: currentIntervalRef.current,
      points: [point],
      color: '#f59e0b', // amber color
      lineWidth: 2,
      lineStyle: 'solid',
      opacity: 1,
      locked: false,
      visible: true,
    }

    currentDrawingRef.current = drawing

    // For single-click tools (hline, hray), save immediately and deselect tool
    if (drawingTool === 'hline' || drawingTool === 'hray') {
      saveDrawing(drawing)
      currentDrawingRef.current = null
      isDrawingRef.current = false
      setDrawingTool(null) // Auto-deselect tool
    }

    // Redraw to show the starting point for two-point tools
    drawOnCanvasRef.current?.()
  }, [drawingTool, coordinateToPrice, saveDrawing, findDrawingAtPoint, findHandleAtPoint, selectedDrawingId, getCurrentDrawings])

  const handleCanvasMouseMove = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = e.currentTarget.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    // Handle dragging (moving or resizing)
    if (isDraggingRef.current && dragStartRef.current) {
      const currentPoint = coordinateToPrice(x, y)
      if (!currentPoint) return

      const startDrawing = dragStartRef.current.drawing

      if (dragHandleRef.current) {
        // Dragging a handle - update only that point
        const newPoints = [...startDrawing.points]
        newPoints[dragHandleRef.current.handleIndex] = currentPoint
        
        // Update the drawing directly in the ref and in storage
        const key = getDrawingsKey(currentSymbolRef.current, currentIntervalRef.current)
        const drawings = drawingsRef.current.get(key) || []
        const index = drawings.findIndex(d => d.id === dragHandleRef.current!.drawingId)
        if (index !== -1) {
          drawings[index] = { ...drawings[index], points: newPoints }
          drawingsRef.current.set(key, [...drawings])
        }
        
        // Update drag start for smooth continuous dragging
        dragStartRef.current = { 
          x, 
          y, 
          drawing: { ...startDrawing, points: newPoints }
        }
        
        drawOnCanvasRef.current?.()
      } else {
        // Dragging entire drawing - move all points
        const startPoint = coordinateToPrice(dragStartRef.current.x, dragStartRef.current.y)
        if (!startPoint) return

        const deltaX = currentPoint.logicalIndex - startPoint.logicalIndex
        const deltaY = currentPoint.price - startPoint.price

        const newPoints = startDrawing.points.map(p => ({
          ...p,
          logicalIndex: p.logicalIndex + deltaX,
          price: p.price + deltaY,
          time: p.time + (deltaX * 300) // Approximate time shift (assuming 5m candles)
        }))

        // Update the drawing directly
        const key = getDrawingsKey(currentSymbolRef.current, currentIntervalRef.current)
        const drawings = drawingsRef.current.get(key) || []
        const index = drawings.findIndex(d => d.id === startDrawing.id)
        if (index !== -1) {
          drawings[index] = { ...drawings[index], points: newPoints }
          drawingsRef.current.set(key, [...drawings])
        }

        // Update drag start position for smooth continuous dragging
        dragStartRef.current = { 
          x, 
          y, 
          drawing: { ...startDrawing, points: newPoints }
        }
        
        drawOnCanvasRef.current?.()
      }
      return
    }

    // Always update mouse position for preview
    if (drawingTool && !isDrawingRef.current) {
      const point = coordinateToPrice(x, y)
      if (point) {
        mousePositionRef.current = { x, y, price: point.price, logicalIndex: point.logicalIndex, time: point.time }
        drawOnCanvasRef.current?.()
      }
    }

    if (!isDrawingRef.current || !currentDrawingRef.current || !drawingTool) return

    const point = coordinateToPrice(x, y)
    if (!point) return

    const drawing = currentDrawingRef.current

    // For pencil, add all points
    if (drawingTool === 'pencil') {
      drawing.points.push(point)
    } else {
      // For two-point tools, update second point
      if (drawing.points.length === 1) {
        drawing.points.push(point)
      } else if (drawing.points.length >= 2) {
        drawing.points[1] = point
      }
    }

    currentDrawingRef.current = drawing
    drawOnCanvasRef.current?.()
  }, [drawingTool, coordinateToPrice])

  const handleCanvasMouseUp = useCallback(() => {
    // Handle end of dragging
    if (isDraggingRef.current) {
      isDraggingRef.current = false
      dragStartRef.current = null
      dragHandleRef.current = null
      return
    }

    if (!isDrawingRef.current || !currentDrawingRef.current) return

    let drawing = currentDrawingRef.current

    // For pencil, simplify points
    if (drawing.type === 'pencil' && drawing.points.length > 2) {
      drawing = {
        ...drawing,
        points: simplifyPoints(drawing.points, 0.00001),
      }
    }

    // Save drawing if it has valid points
    // For trendline, trendray, rectangle, fibonacci need at least 2 points
    // Ruler is temporary - not saved
    if (drawing.type === 'ruler') {
      // Ruler is temporary, don't save - just clear
      currentDrawingRef.current = null
      isDrawingRef.current = false
      setDrawingTool(null) // Auto-deselect tool
      drawOnCanvasRef.current?.()
      return
    }

    if (drawing.type === 'trendline' || drawing.type === 'trendray' || drawing.type === 'rectangle' || drawing.type === 'fibonacci') {
      if (drawing.points.length >= 2) {
        saveDrawing(drawing)
      }
    } else if (drawing.points.length >= 1) {
      saveDrawing(drawing)
    }

    currentDrawingRef.current = null
    isDrawingRef.current = false
    setDrawingTool(null) // Auto-deselect tool after drawing
    drawOnCanvasRef.current?.()
  }, [saveDrawing])

  const handleCanvasMouseLeave = useCallback(() => {
    mousePositionRef.current = null
    if (!isDrawingRef.current) {
      drawOnCanvasRef.current?.()
    }
  }, [])

  // Handle drag movement with constraints based on drawing type
  // Must be defined before handleChartContainerMouseDown which uses it
  const handleDragMove = useCallback((x: number, y: number) => {
    if (!isDraggingRef.current || !dragStartRef.current) return

    const currentPoint = coordinateToPrice(x, y)
    if (!currentPoint) return

    const startDrawing = dragStartRef.current.drawing
    const drawingType = startDrawing.type

    if (dragHandleRef.current) {
      // Dragging a handle
      const handleIndex = dragHandleRef.current.handleIndex
      let newPoints: DrawingPoint[]

      // Special handling for rectangle - 4 corner handles
      if (drawingType === 'rectangle' && startDrawing.points.length >= 2) {
        const p1 = startDrawing.points[0]
        const p2 = startDrawing.points[1]

        // Determine current bounds
        const leftLogical = Math.min(p1.logicalIndex, p2.logicalIndex)
        const rightLogical = Math.max(p1.logicalIndex, p2.logicalIndex)
        const topPrice = Math.max(p1.price, p2.price)
        const bottomPrice = Math.min(p1.price, p2.price)

        // Update based on which corner is being dragged
        // The rectangle is defined by two opposite corners
        // When dragging a corner, we need to update the points to be the new opposite corners
        switch (handleIndex) {
          case 0: // top-left corner dragged
            // New corners: (currentX, topPrice) and (rightLogical, currentPrice)
            // But we want to stretch, so current point becomes one corner, opposite stays
            newPoints = [
              { logicalIndex: currentPoint.logicalIndex, price: currentPoint.price, time: currentPoint.time },
              { logicalIndex: rightLogical, price: bottomPrice, time: p2.time }
            ]
            break
          case 1: // top-right corner dragged
            newPoints = [
              { logicalIndex: leftLogical, price: bottomPrice, time: p1.time },
              { logicalIndex: currentPoint.logicalIndex, price: currentPoint.price, time: currentPoint.time }
            ]
            break
          case 2: // bottom-left corner dragged
            newPoints = [
              { logicalIndex: currentPoint.logicalIndex, price: currentPoint.price, time: currentPoint.time },
              { logicalIndex: rightLogical, price: topPrice, time: p2.time }
            ]
            break
          case 3: // bottom-right corner dragged
            newPoints = [
              { logicalIndex: leftLogical, price: topPrice, time: p1.time },
              { logicalIndex: currentPoint.logicalIndex, price: currentPoint.price, time: currentPoint.time }
            ]
            break
          default:
            newPoints = startDrawing.points
        }
      } else {
        // For other drawings, update the specific point
        newPoints = [...startDrawing.points]

        // For hline and hray, handles only move vertically (price only)
        if (drawingType === 'hline' || drawingType === 'hray') {
          newPoints[handleIndex] = {
            ...startDrawing.points[handleIndex],
            price: currentPoint.price,
          }
        } else {
          // For trendline, trendray, fibonacci - full movement
          newPoints[handleIndex] = currentPoint
        }
      }

      // Update the drawing directly in storage
      const key = getDrawingsKey(currentSymbolRef.current, currentIntervalRef.current)
      const drawings = drawingsRef.current.get(key) || []
      const index = drawings.findIndex(d => d.id === dragHandleRef.current!.drawingId)
      if (index !== -1) {
        drawings[index] = { ...drawings[index], points: newPoints }
        drawingsRef.current.set(key, [...drawings])
      }

      // Update drag start for smooth continuous dragging
      dragStartRef.current = {
        x,
        y,
        drawing: { ...startDrawing, points: newPoints }
      }
    } else {
      // Dragging entire drawing - apply constraints based on type
      const startPoint = coordinateToPrice(dragStartRef.current.x, dragStartRef.current.y)
      if (!startPoint) return

      let newPoints: DrawingPoint[]

      if (drawingType === 'hline') {
        // hline: vertical movement only (price changes, logicalIndex stays same)
        const deltaY = currentPoint.price - startPoint.price
        newPoints = startDrawing.points.map(p => ({
          ...p,
          price: p.price + deltaY,
        }))
      } else if (drawingType === 'hray') {
        // hray: horizontal and vertical movement
        const deltaX = currentPoint.logicalIndex - startPoint.logicalIndex
        const deltaY = currentPoint.price - startPoint.price
        newPoints = startDrawing.points.map(p => ({
          ...p,
          logicalIndex: p.logicalIndex + deltaX,
          price: p.price + deltaY,
          time: p.time + (deltaX * 300)
        }))
      } else {
        // trendline, trendray, rectangle, fibonacci, pencil: full movement
        const deltaX = currentPoint.logicalIndex - startPoint.logicalIndex
        const deltaY = currentPoint.price - startPoint.price
        newPoints = startDrawing.points.map(p => ({
          ...p,
          logicalIndex: p.logicalIndex + deltaX,
          price: p.price + deltaY,
          time: p.time + (deltaX * 300)
        }))
      }

      // Update the drawing directly
      const key = getDrawingsKey(currentSymbolRef.current, currentIntervalRef.current)
      const drawings = drawingsRef.current.get(key) || []
      const index = drawings.findIndex(d => d.id === startDrawing.id)
      if (index !== -1) {
        drawings[index] = { ...drawings[index], points: newPoints }
        drawingsRef.current.set(key, [...drawings])
      }

      // Update drag start position
      dragStartRef.current = {
        x,
        y,
        drawing: { ...startDrawing, points: newPoints }
      }
    }

    drawOnCanvasRef.current?.()
  }, [coordinateToPrice])

  // Handle chart container events for selecting/moving drawings when no tool is selected
  // Using capture phase to intercept events before lightweight-charts processes them
  const handleChartContainerMouseDown = useCallback((e: MouseEvent) => {
    // Only handle when no drawing tool is selected
    if (drawingTool) return

    const canvas = drawingCanvasRef.current
    if (!canvas || !chartRef.current) return

    const rect = canvas.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    // Check if clicking on a handle of selected drawing
    if (selectedDrawingId) {
      const handleIndex = findHandleAtPoint(x, y, selectedDrawingId)
      if (handleIndex !== null) {
        e.stopPropagation()
        e.preventDefault()

        // Start dragging handle
        const drawings = getCurrentDrawings()
        const drawing = drawings.find(d => d.id === selectedDrawingId)
        if (drawing) {
          isDraggingRef.current = true
          dragHandleRef.current = { drawingId: selectedDrawingId, handleIndex }
          dragStartRef.current = { x, y, drawing: JSON.parse(JSON.stringify(drawing)) }

          // Add temporary move and up handlers on document
          const handleMove = (moveE: MouseEvent) => {
            const moveX = moveE.clientX - rect.left
            const moveY = moveE.clientY - rect.top
            handleDragMove(moveX, moveY)
          }

          const handleUp = () => {
            isDraggingRef.current = false
            dragStartRef.current = null
            dragHandleRef.current = null
            document.removeEventListener('mousemove', handleMove)
            document.removeEventListener('mouseup', handleUp)
          }

          document.addEventListener('mousemove', handleMove)
          document.addEventListener('mouseup', handleUp)
        }
        return
      }
    }

    // Check for drawing selection
    const foundDrawing = findDrawingAtPoint(x, y)
    if (foundDrawing) {
      e.stopPropagation()
      e.preventDefault()

      setSelectedDrawingId(foundDrawing.id)
      drawOnCanvasRef.current?.()

      // Start dragging the entire drawing
      isDraggingRef.current = true
      dragStartRef.current = { x, y, drawing: JSON.parse(JSON.stringify(foundDrawing)) }
      dragHandleRef.current = null

      // Add temporary move and up handlers on document
      const handleMove = (moveE: MouseEvent) => {
        const moveX = moveE.clientX - rect.left
        const moveY = moveE.clientY - rect.top
        handleDragMove(moveX, moveY)
      }

      const handleUp = () => {
        isDraggingRef.current = false
        dragStartRef.current = null
        dragHandleRef.current = null
        document.removeEventListener('mousemove', handleMove)
        document.removeEventListener('mouseup', handleUp)
      }

      document.addEventListener('mousemove', handleMove)
      document.addEventListener('mouseup', handleUp)
    } else {
      setSelectedDrawingId(null)
      drawOnCanvasRef.current?.()
    }
  }, [drawingTool, selectedDrawingId, findHandleAtPoint, findDrawingAtPoint, getCurrentDrawings, handleDragMove])

  // Handle hover over drawings to show appropriate cursor
  const handleChartContainerMouseMove = useCallback((e: MouseEvent) => {
    // Only handle when no drawing tool is selected
    if (drawingTool) return

    const container = chartContainerRef.current
    if (!container) return

    const rect = container.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    // Check if hovering over a handle of selected drawing
    if (selectedDrawingId) {
      const handleIndex = findHandleAtPoint(x, y, selectedDrawingId)
      if (handleIndex !== null) {
        const drawings = getCurrentDrawings()
        const drawing = drawings.find(d => d.id === selectedDrawingId)
        if (drawing) {
          // For rectangle, show different cursors for different corners
          if (drawing.type === 'rectangle') {
            // handleIndex: 0=top-left, 1=top-right, 2=bottom-left, 3=bottom-right
            if (handleIndex === 0 || handleIndex === 3) {
              container.style.cursor = 'nwse-resize' // diagonal \
            } else {
              container.style.cursor = 'nesw-resize' // diagonal /
            }
            return
          }
          // For other tools with handles
          if (drawing.type === 'trendline' || drawing.type === 'trendray' || drawing.type === 'fibonacci') {
            container.style.cursor = 'nwse-resize'
            return
          }
          // For hline and hray, show vertical resize cursor on handle
          if (drawing.type === 'hline' || drawing.type === 'hray') {
            container.style.cursor = 'ns-resize'
            return
          }
        }
      }
    }

    // Check if hovering over any drawing
    const foundDrawing = findDrawingAtPoint(x, y)
    if (foundDrawing) {
      if (foundDrawing.type === 'hline') {
        container.style.cursor = 'ns-resize' // vertical resize cursor
      } else if (foundDrawing.type === 'hray') {
        container.style.cursor = 'move' // move cursor
      } else {
        container.style.cursor = 'move' // move cursor
      }
    } else {
      container.style.cursor = 'default'
    }
  }, [drawingTool, selectedDrawingId, findHandleAtPoint, findDrawingAtPoint, getCurrentDrawings])

  // Handle mouse leave to reset cursor
  const handleChartContainerMouseLeave = useCallback(() => {
    const container = chartContainerRef.current
    if (container) {
      container.style.cursor = 'default'
    }
  }, [])

  // Set up chart container event listener for drawing selection and hover
  // Using capture phase (true) to intercept events BEFORE lightweight-charts processes them
  useEffect(() => {
    if (pageMode !== 'single') return

    const container = chartContainerRef.current
    if (!container) return

    // Use capture phase to intercept events before they reach lightweight-charts
    container.addEventListener('mousedown', handleChartContainerMouseDown, true)
    container.addEventListener('mousemove', handleChartContainerMouseMove)
    container.addEventListener('mouseleave', handleChartContainerMouseLeave)

    return () => {
      container.removeEventListener('mousedown', handleChartContainerMouseDown, true)
      container.removeEventListener('mousemove', handleChartContainerMouseMove)
      container.removeEventListener('mouseleave', handleChartContainerMouseLeave)
    }
  }, [pageMode, handleChartContainerMouseDown, handleChartContainerMouseMove, handleChartContainerMouseLeave])

  // Middle mouse button handlers for temporary ruler (using native events on chart container)
  const handleMiddleMouseDown = useCallback((e: MouseEvent) => {
    // Only handle middle mouse button (button 1)
    if (e.button !== 1) return

    e.preventDefault()
    e.stopPropagation()

    const canvas = drawingCanvasRef.current
    if (!canvas || !chartRef.current) return

    const rect = canvas.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    const point = coordinateToPrice(x, y)
    if (!point) return

    isTempRulerRef.current = true

    const drawing: Drawing = {
      id: generateId(),
      type: 'ruler',
      symbol: currentSymbolRef.current,
      interval: currentIntervalRef.current,
      points: [point],
      color: '#06b6d4', // cyan color for temporary ruler
      ...DEFAULT_DRAWING_SETTINGS,
      color: '#06b6d4', // Override color for ruler
    }

    tempRulerRef.current = drawing

    // Enable canvas for move events during ruler drag
    canvas.style.pointerEvents = 'auto'

    drawOnCanvasRef.current?.()
  }, [coordinateToPrice])

  const handleMiddleMouseMove = useCallback((e: MouseEvent) => {
    if (!isTempRulerRef.current || !tempRulerRef.current) return

    const canvas = drawingCanvasRef.current
    if (!canvas) return

    const rect = canvas.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top

    const point = coordinateToPrice(x, y)
    if (!point) return

    // Update second point
    tempRulerRef.current = {
      ...tempRulerRef.current,
      points: [tempRulerRef.current.points[0], point]
    }
    drawOnCanvasRef.current?.()
  }, [coordinateToPrice])

  const handleMiddleMouseUp = useCallback((e: MouseEvent) => {
    // Only handle middle mouse button (button 1)
    if (e.button !== 1) return

    // Clear temporary ruler when middle mouse button is released
    isTempRulerRef.current = false
    tempRulerRef.current = null

    // Disable canvas if no tool selected
    const canvas = drawingCanvasRef.current
    if (canvas && !drawingTool) {
      canvas.style.pointerEvents = 'none'
    }

    drawOnCanvasRef.current?.()
  }, [drawingTool])

  // Set up native event listeners for middle mouse button on chart container
  useEffect(() => {
    if (pageMode !== 'single') return

    const container = chartContainerRef.current
    if (!container) return

    container.addEventListener('mousedown', handleMiddleMouseDown)
    // Use document for mousemove and mouseup to capture events outside container
    document.addEventListener('mousemove', handleMiddleMouseMove)
    document.addEventListener('mouseup', handleMiddleMouseUp)

    return () => {
      container.removeEventListener('mousedown', handleMiddleMouseDown)
      document.removeEventListener('mousemove', handleMiddleMouseMove)
      document.removeEventListener('mouseup', handleMiddleMouseUp)
    }
  }, [pageMode, handleMiddleMouseDown, handleMiddleMouseMove, handleMiddleMouseUp])

  // Multi-chart page
  if (pageMode === 'multi') {
    const totalRows = Math.ceil(tickers.length / CHARTS_PER_ROW)
    const chartHeight = 280
    const totalHeight = totalRows * (chartHeight + 8) - 8 // 8px gap
    
    // Calculate visible range
    const startRow = Math.max(0, scrollOffset - ROW_BUFFER)
    const endRow = Math.min(totalRows, scrollOffset + ROWS_VISIBLE + ROW_BUFFER)
    
    const startIdx = startRow * CHARTS_PER_ROW
    const endIdx = Math.min(tickers.length, endRow * CHARTS_PER_ROW)
    const visibleTickers = tickers.slice(startIdx, endIdx)
    
    const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
      const scrollTop = e.currentTarget.scrollTop
      const newOffset = Math.floor(scrollTop / (chartHeight + 8))
      setScrollOffset(newOffset)
    }

    return (
      <div className="flex flex-col w-screen h-screen bg-background overflow-hidden">
        {/* Top Header Bar */}
        <div className="h-[28px] flex-shrink-0 border-b-2 border-border/80 bg-card flex items-center px-3 justify-between">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setPageMode('single')}
              className="p-1 text-xs font-medium rounded transition-colors bg-primary text-primary-foreground hover:bg-primary/80"
            >
              <Maximize2 className="w-3.5 h-3.5" />
            </button>
            <span className="text-xs font-medium">Multi Chart View ({tickers.length} tickers)</span>
          </div>
        </div>

        {/* Charts Grid with Virtual Scroll */}
        <div className="flex-1 p-2 overflow-hidden relative">
          <ScrollArea 
            className="h-full border-r-2 border-border/80" 
            scrollBarClassName="bg-black hover:bg-zinc-800 opacity-100!"
            onScroll={handleScroll}
          >
            <div style={{ height: totalHeight, position: 'relative' }}>
              <div 
                className="grid grid-cols-3 gap-2 pr-2 absolute w-full"
                style={{ top: startRow * (chartHeight + 8) }}
              >
                {visibleTickers.map((ticker, idx) => {
                  const symbol = ticker.symbol
                  return (
                    <div key={symbol} className="border-2 border-black rounded-none bg-card overflow-hidden" style={{ height: chartHeight }}>
                      <MiniChart
                        symbol={symbol}
                        interval={multiChartIntervals[symbol] || '5m'}
                        limit={500}
                        showVolume={true}
                        ticker={{
                          priceChangePercent: ticker.priceChangePercent,
                          lastPrice: ticker.lastPrice,
                          highPrice: ticker.highPrice,
                          lowPrice: ticker.lowPrice,
                          volume: ticker.volume,
                          count: ticker.count,
                        }}
                        onIntervalChange={(interval) => handleMultiChartIntervalChange(symbol, interval)}
                      />
                    </div>
                  )
                })}
              </div>
            </div>
          </ScrollArea>
        </div>
      </div>
    )
  }

  // Single chart page (original)
  return (
    <div className="flex flex-col w-screen h-screen bg-background overflow-hidden">
      {/* Top Header Bar */}
      <div className="h-[28px] flex-shrink-0 border-b-2 border-border/80 bg-card flex items-center px-3 justify-between">
        <div></div>
        <button
          onClick={() => setPageMode('multi')}
          className="p-1 text-xs font-medium rounded transition-colors bg-primary text-primary-foreground hover:bg-primary/80"
        >
          <LayoutGrid className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Left: Tickers Sidebar OR narrow panel */}
        {showTickers ? (
          <div className="w-[420px] flex-shrink-0 bg-card flex flex-col h-full overflow-hidden border-r-2 border-border/80">
            {/* Table Header */}
            <div className="relative flex py-2 text-[11px] text-muted-foreground border-b-2 border-border/80 flex-shrink-0 bg-card font-medium items-center">
              <div className="w-[80px] text-left px-2">Тикер</div>
              <div className="w-[75px] text-right">Цена</div>
              <div className="w-[50px] text-right">Изм</div>
              <div className="w-[45px] text-right">Ренж</div>
              <div className="w-[40px] text-right">NATR</div>
              <div className="w-[50px] text-right">Сделки</div>
              <div className="w-[50px] text-right">Объём</div>
              {/* Collapse button */}
              <button
                onClick={() => setShowTickers(false)}
                className="absolute right-0 top-0 bottom-0 w-2.5 bg-black hover:bg-zinc-800 flex items-center justify-center transition-colors"
              >
                <ChevronLeft className="w-2 h-2 text-white stroke-[3]" />
              </button>
            </div>

            {/* Tickers List */}
            <div className="flex-1 min-h-0 overflow-hidden">
              <ScrollArea className="h-full" scrollBarClassName="bg-black hover:bg-zinc-800 opacity-100!">
                <div>
                  {tickersLoading ? (
                    <div className="p-3 text-center text-muted-foreground text-sm">Загрузка...</div>
                  ) : (
                    <div>
                      {tickers.map((ticker) => (
                        <button
                          key={ticker.symbol}
                          onClick={() => handleTickerClick(ticker.symbol)}
                          className={`w-full flex items-center py-2 text-xs transition-colors ${
                            selectedSymbol === ticker.symbol 
                              ? 'bg-accent border-2 border-primary' 
                              : 'border-b border-border/50 hover:bg-accent/90'
                          }`}
                        >
                          {/* Ticker */}
                          <div className="w-[80px] flex items-center gap-1 text-left flex-shrink-0 px-2">
                            {ticker.priceChangePercent >= 0 ? (
                              <TrendingUp className="w-3 h-3 flex-shrink-0 text-green-500" />
                            ) : (
                              <TrendingDown className="w-3 h-3 flex-shrink-0 text-red-500" />
                            )}
                            <span className="font-medium">{ticker.baseAsset}</span>
                          </div>
                          
                          {/* Price */}
                          <div className="w-[75px] text-right tabular-nums flex-shrink-0">
                            {formatPrice(ticker.lastPrice)}
                          </div>
                          
                          {/* Daily Change */}
                          <div className={`w-[50px] text-right tabular-nums flex-shrink-0 ${
                            ticker.priceChangePercent >= 0 ? 'text-green-500' : 'text-red-500'
                          }`}>
                            {formatChange(ticker.priceChangePercent)}
                          </div>
                          
                          {/* Range */}
                          <div className="w-[45px] text-right text-[11px] tabular-nums text-muted-foreground flex-shrink-0">
                            {calcNATR(ticker)}%
                          </div>
                          
                          {/* NATR */}
                          <div className="w-[40px] text-right text-[11px] tabular-nums text-muted-foreground flex-shrink-0">
                            {calcNATR(ticker)}
                          </div>
                          
                          {/* Count (Trades) */}
                          <div className="w-[50px] text-right text-[11px] tabular-nums text-muted-foreground flex-shrink-0">
                            {formatCount(ticker.count)}
                          </div>
                          
                          {/* Volume */}
                          <div className="w-[50px] text-right text-[11px] tabular-nums flex-shrink-0">
                            {formatVolume(ticker.volume)}
                          </div>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </ScrollArea>
            </div>

            {/* Drawing Tool Button - inside tickers panel */}
            <div className="flex-shrink-0 border-t-2 border-border/80 p-2 flex items-center justify-center">
              <button
                title="Карандаш (рисование)"
                onClick={() => setDrawingTool(drawingTool === 'pencil' ? null : 'pencil')}
                className={`p-2 rounded transition-colors ${
                  drawingTool === 'pencil'
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-accent text-muted-foreground hover:text-foreground'
                }`}
              >
                <Pencil className="w-4 h-4" />
              </button>
              <button
                title="Горизонтальный луч"
                onClick={() => setDrawingTool(drawingTool === 'hray' ? null : 'hray')}
                className={`p-2 rounded transition-colors ${
                  drawingTool === 'hray'
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-accent text-muted-foreground hover:text-foreground'
                }`}
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="6" cy="12" r="2" fill="currentColor" />
                  <line x1="8" y1="12" x2="20" y2="12" />
                </svg>
              </button>
              <button
                title="Горизонтальный уровень"
                onClick={() => setDrawingTool(drawingTool === 'hline' ? null : 'hline')}
                className={`p-2 rounded transition-colors ${
                  drawingTool === 'hline'
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-accent text-muted-foreground hover:text-foreground'
                }`}
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="4" y1="12" x2="20" y2="12" />
                </svg>
              </button>
              <button
                title="Линия тренда"
                onClick={() => setDrawingTool(drawingTool === 'trendline' ? null : 'trendline')}
                className={`p-2 rounded transition-colors ${
                  drawingTool === 'trendline'
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-accent text-muted-foreground hover:text-foreground'
                }`}
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="4" cy="20" r="2" fill="currentColor" />
                  <circle cx="20" cy="4" r="2" fill="currentColor" />
                  <line x1="4" y1="20" x2="20" y2="4" />
                </svg>
              </button>
              <button
                title="Трендовый луч"
                onClick={() => setDrawingTool(drawingTool === 'trendray' ? null : 'trendray')}
                className={`p-2 rounded transition-colors ${
                  drawingTool === 'trendray'
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-accent text-muted-foreground hover:text-foreground'
                }`}
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="4" cy="20" r="2" fill="currentColor" />
                  <line x1="4" y1="20" x2="22" y2="2" />
                </svg>
              </button>
              <button
                title="Прямоугольник"
                onClick={() => setDrawingTool(drawingTool === 'rectangle' ? null : 'rectangle')}
                className={`p-2 rounded transition-colors ${
                  drawingTool === 'rectangle'
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-accent text-muted-foreground hover:text-foreground'
                }`}
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="3" y="3" width="18" height="18" rx="2" />
                </svg>
              </button>
              <button
                title="Линии Фибоначчи"
                onClick={() => setDrawingTool(drawingTool === 'fibonacci' ? null : 'fibonacci')}
                className={`p-2 rounded transition-colors ${
                  drawingTool === 'fibonacci'
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-accent text-muted-foreground hover:text-foreground'
                }`}
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="4" y1="20" x2="20" y2="20" />
                  <line x1="4" y1="14" x2="20" y2="14" />
                  <line x1="4" y1="10" x2="20" y2="10" />
                  <line x1="4" y1="6" x2="20" y2="6" />
                  <circle cx="4" cy="20" r="1.5" fill="currentColor" />
                  <circle cx="4" cy="6" r="1.5" fill="currentColor" />
                </svg>
              </button>
              <button
                title="Рулетка"
                onClick={() => setDrawingTool(drawingTool === 'ruler' ? null : 'ruler')}
                className={`p-2 rounded transition-colors ${
                  drawingTool === 'ruler'
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-accent text-muted-foreground hover:text-foreground'
                }`}
              >
                <Ruler className="w-4 h-4" />
              </button>
            </div>
          </div>
        ) : (
          /* Narrow left panel when tickers hidden */
          <div className="w-[36px] flex-shrink-0 bg-card flex flex-col h-full border-r-2 border-border/80">
            <div className="h-[36px] flex items-center justify-center border-b-2 border-border/80">
              <button
                onClick={() => {
                  setShowTickers(true)
                  setShowRightPanel(true) // Reset right panel when opening tickers
                }}
                className="p-1 text-xs font-medium rounded transition-colors bg-primary text-primary-foreground hover:bg-primary/80"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
            {/* Drawing Tools */}
            <div className="flex flex-col items-center py-2 gap-1">
              <button
                title="Карандаш (рисование)"
                onClick={() => setDrawingTool(drawingTool === 'pencil' ? null : 'pencil')}
                className={`p-2 rounded transition-colors ${
                  drawingTool === 'pencil'
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-accent text-muted-foreground hover:text-foreground'
                }`}
              >
                <Pencil className="w-4 h-4" />
              </button>
              <button
                title="Горизонтальный луч"
                onClick={() => setDrawingTool(drawingTool === 'hray' ? null : 'hray')}
                className={`p-2 rounded transition-colors ${
                  drawingTool === 'hray'
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-accent text-muted-foreground hover:text-foreground'
                }`}
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="6" cy="12" r="2" fill="currentColor" />
                  <line x1="8" y1="12" x2="20" y2="12" />
                </svg>
              </button>
              <button
                title="Горизонтальный уровень"
                onClick={() => setDrawingTool(drawingTool === 'hline' ? null : 'hline')}
                className={`p-2 rounded transition-colors ${
                  drawingTool === 'hline'
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-accent text-muted-foreground hover:text-foreground'
                }`}
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="4" y1="12" x2="20" y2="12" />
                </svg>
              </button>
              <button
                title="Линия тренда"
                onClick={() => setDrawingTool(drawingTool === 'trendline' ? null : 'trendline')}
                className={`p-2 rounded transition-colors ${
                  drawingTool === 'trendline'
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-accent text-muted-foreground hover:text-foreground'
                }`}
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="4" cy="20" r="2" fill="currentColor" />
                  <circle cx="20" cy="4" r="2" fill="currentColor" />
                  <line x1="4" y1="20" x2="20" y2="4" />
                </svg>
              </button>
              <button
                title="Трендовый луч"
                onClick={() => setDrawingTool(drawingTool === 'trendray' ? null : 'trendray')}
                className={`p-2 rounded transition-colors ${
                  drawingTool === 'trendray'
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-accent text-muted-foreground hover:text-foreground'
                }`}
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="4" cy="20" r="2" fill="currentColor" />
                  <line x1="4" y1="20" x2="22" y2="2" />
                </svg>
              </button>
              <button
                title="Прямоугольник"
                onClick={() => setDrawingTool(drawingTool === 'rectangle' ? null : 'rectangle')}
                className={`p-2 rounded transition-colors ${
                  drawingTool === 'rectangle'
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-accent text-muted-foreground hover:text-foreground'
                }`}
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <rect x="3" y="3" width="18" height="18" rx="2" />
                </svg>
              </button>
              <button
                title="Линии Фибоначчи"
                onClick={() => setDrawingTool(drawingTool === 'fibonacci' ? null : 'fibonacci')}
                className={`p-2 rounded transition-colors ${
                  drawingTool === 'fibonacci'
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-accent text-muted-foreground hover:text-foreground'
                }`}
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="4" y1="20" x2="20" y2="20" />
                  <line x1="4" y1="14" x2="20" y2="14" />
                  <line x1="4" y1="10" x2="20" y2="10" />
                  <line x1="4" y1="6" x2="20" y2="6" />
                  <circle cx="4" cy="20" r="1.5" fill="currentColor" />
                  <circle cx="4" cy="6" r="1.5" fill="currentColor" />
                </svg>
              </button>
              <button
                title="Рулетка"
                onClick={() => setDrawingTool(drawingTool === 'ruler' ? null : 'ruler')}
                className={`p-2 rounded transition-colors ${
                  drawingTool === 'ruler'
                    ? 'bg-primary text-primary-foreground'
                    : 'hover:bg-accent text-muted-foreground hover:text-foreground'
                }`}
              >
                <Ruler className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Chart */}
        <div className="flex-1 h-full overflow-hidden relative flex flex-col">
          {/* Top Bar with Symbol Info and Timeframe Buttons */}
          <div className="flex-shrink-0 z-20 flex items-center h-[36px] px-3 border-b-2 border-border/80">
            {/* Ticker Navigation */}
            <div className="flex items-center gap-1">
              <button
                onClick={() => {
                  const currentIndex = tickers.findIndex(t => t.symbol === selectedSymbol)
                  if (currentIndex > 0) {
                    setSelectedSymbol(tickers[currentIndex - 1].symbol)
                  }
                }}
                className="p-1 text-xs font-medium rounded transition-colors bg-primary text-primary-foreground hover:bg-primary/80"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  const currentIndex = tickers.findIndex(t => t.symbol === selectedSymbol)
                  if (currentIndex < tickers.length - 1) {
                    setSelectedSymbol(tickers[currentIndex + 1].symbol)
                  }
                }}
                className="p-1 text-xs font-medium rounded transition-colors bg-primary text-primary-foreground hover:bg-primary/80"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center gap-2 ml-2">
              <span
                onClick={() => {
                  navigator.clipboard.writeText(selectedSymbol)
                }}
                className="text-xs font-medium border-2 border-black px-2 py-0.5 rounded cursor-pointer hover:bg-accent transition-colors"
              >
                {selectedSymbol}
              </span>
              <span className="text-xs text-muted-foreground">Perpetual</span>
            </div>
            {tickers.find(t => t.symbol === selectedSymbol) && (
              <>
                <span className="tabular-nums text-xs ml-4">{formatPrice(tickers.find(t => t.symbol === selectedSymbol)!.lastPrice)}</span>
                <span className={`tabular-nums text-xs ml-2 ${tickers.find(t => t.symbol === selectedSymbol)!.priceChangePercent >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                  {formatChange(tickers.find(t => t.symbol === selectedSymbol)!.priceChangePercent)}%
                </span>
                <span className="tabular-nums text-xs text-muted-foreground ml-2">R: {calcNATR(tickers.find(t => t.symbol === selectedSymbol)!)}%</span>
                <span className="tabular-nums text-xs text-muted-foreground ml-2">NATR: {calcNATR(tickers.find(t => t.symbol === selectedSymbol)!)}</span>
                <span className="tabular-nums text-xs text-muted-foreground ml-2">Сделки: {formatCount(tickers.find(t => t.symbol === selectedSymbol)!.count)}</span>
                <span className="tabular-nums text-xs text-muted-foreground ml-2">Объём: {formatVolume(tickers.find(t => t.symbol === selectedSymbol)!.volume)}</span>
              </>
            )}

            {/* Timeframe Buttons */}
            <div className="flex items-center gap-1 ml-4">
              {timeframes.map((tf) => (
                <button
                  key={tf}
                  onClick={() => handleIntervalChange(tf)}
                  className={`px-2 py-1 text-xs font-medium rounded transition-colors ${
                    selectedInterval === tf
                      ? 'bg-card text-foreground underline decoration-2 underline-offset-4'
                      : 'bg-card hover:bg-accent text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {tf}
                </button>
              ))}
            </div>
          </div>
          <div className="flex-1 relative">
            {loading && (
              <div className="absolute inset-0 flex items-center justify-center bg-background/50 z-10">
                <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
              </div>
            )}
            <div ref={chartContainerRef} className="absolute inset-0" />
            {/* Drawing Canvas Overlay */}
            <canvas
              ref={drawingCanvasRef}
              className="absolute inset-0"
              style={{
                zIndex: 100,
                pointerEvents: drawingTool ? 'auto' : 'none',
                width: '100%',
                height: '100%',
                cursor: drawingTool ? 'crosshair' : 'default'
              }}
              onMouseDown={handleCanvasMouseDown}
              onMouseMove={handleCanvasMouseMove}
              onMouseUp={handleCanvasMouseUp}
              onMouseLeave={() => {
                handleCanvasMouseUp()
                handleCanvasMouseLeave()
              }}
              onContextMenu={(e) => e.preventDefault()}
            />
            {/* Drawing Settings Menu */}
            <DrawingSettingsMenu
              isOpen={!!selectedDrawingId}
              drawingType={getSelectedDrawing()?.type || null}
              settings={getSelectedDrawingSettings()}
              onSettingsChange={handleDrawingSettingsChange}
              onDelete={() => {
                if (selectedDrawingId) {
                  deleteDrawing(selectedDrawingId)
                }
              }}
              onDuplicate={handleDuplicateDrawing}
              onClose={() => setSelectedDrawingId(null)}
            />
          </div>
        </div>

        {/* Right Panel - slides in when tickers hidden */}
        {!showTickers && (
          showRightPanel ? (
            <div 
              className="relative w-[400px] flex-shrink-0 bg-card flex flex-col h-full overflow-hidden border-l-2 border-border/80 transition-all duration-300 ease-out"
            >
              {/* Collapse button - full height with icon at header center */}
              <button
                onClick={() => setShowRightPanel(false)}
                className="absolute left-0 top-0 bottom-0 w-2.5 bg-black hover:bg-zinc-800 transition-colors z-10"
              >
                <span className="absolute top-[12px] left-1/2 -translate-x-1/2">
                  <ChevronRight className="w-3 h-3 text-white stroke-[3]" />
                </span>
              </button>
              {/* Header */}
              <div className="h-[36px] flex items-center px-3 border-b-2 border-border/80 flex-shrink-0 ml-2.5">
                <span className="text-xs font-medium">Правая панель</span>
              </div>
              <div className="flex-1 p-3 overflow-auto ml-2.5">
                {/* Сюда можно добавить контент */}
                <p className="text-xs text-muted-foreground">Здесь может быть дополнительная информация...</p>
              </div>
            </div>
          ) : (
            /* Narrow right panel when right panel hidden */
            <div className="w-[36px] flex-shrink-0 bg-card flex flex-col h-full border-l-2 border-border/80 transition-all duration-300 ease-out">
              <div className="h-[36px] flex items-center justify-center border-b-2 border-border/80">
                <button
                  onClick={() => setShowRightPanel(true)}
                  className="p-1 text-xs font-medium rounded transition-colors bg-primary text-primary-foreground hover:bg-primary/80"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
              </div>
            </div>
          )
        )}
      </div>
    </div>
  )
}

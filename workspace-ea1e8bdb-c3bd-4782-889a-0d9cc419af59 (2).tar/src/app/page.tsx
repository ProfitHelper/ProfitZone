'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import {
  createChart,
  IChartApi,
  ISeriesApi,
  CandlestickData,
  HistogramData,
  ColorType,
  Time,
  CandlestickSeries,
  HistogramSeries,
  CandlestickSeriesOptions,
  HistogramSeriesOptions,
  LogicalRange,
} from 'lightweight-charts'
import { ScrollArea } from '@/components/ui/scroll-area'
import { TrendingUp, TrendingDown, ChevronLeft, ChevronRight } from 'lucide-react'
import { Button } from '@/components/ui/button'

interface CandleData {
  time: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

interface ApiResponse {
  symbol: string
  interval: string
  candles: CandleData[]
}

interface Ticker {
  symbol: string
  baseAsset: string
  priceChangePercent: number
  lastPrice: number
  highPrice: number
  lowPrice: number
  volume: number
  count: number
}

// Store chart visible range for each symbol + interval
interface ChartViewState {
  logicalRange: LogicalRange | null
  rightOffset: number
}

export default function Home() {
  const chartContainerRef = useRef<HTMLDivElement>(null)
  const chartRef = useRef<IChartApi | null>(null)
  const candlestickSeriesRef = useRef<ISeriesApi<'Candlestick', Time, CandlestickData<Time>, CandlestickSeriesOptions> | null>(null)
  const volumeSeriesRef = useRef<ISeriesApi<'Histogram', Time, HistogramData<Time>, HistogramSeriesOptions> | null>(null)
  
  // Store visible logical range for each symbol + interval combination
  const viewStateMapRef = useRef<Map<string, ChartViewState>>(new Map())
  // Flag to prevent saving during data load
  const isLoadingDataRef = useRef(false)
  // Track current symbol and interval
  const currentSymbolRef = useRef<string>('')
  const currentIntervalRef = useRef<string>('')

  const [tickers, setTickers] = useState<Ticker[]>([])
  const [selectedSymbol, setSelectedSymbol] = useState('BTCUSDT')
  const [selectedInterval, setSelectedInterval] = useState('5m')
  const [loading, setLoading] = useState(true)
  const [tickersLoading, setTickersLoading] = useState(true)
  const [showTickers, setShowTickers] = useState(true)

  const timeframes = ['1m', '5m', '15m', '1h', '4h', '1d']

  // Default number of visible bars
  const DEFAULT_VISIBLE_BARS = 200

  // Fetch tickers list
  useEffect(() => {
    const fetchTickers = async () => {
      try {
        const response = await fetch('/api/tickers')
        if (!response.ok) throw new Error('Failed to fetch tickers')
        const data = await response.json()
        setTickers(data.tickers)
      } finally {
        setTickersLoading(false)
      }
    }
    fetchTickers()
  }, [])

  // Fetch candle data
  const fetchData = useCallback(async (symbol: string, interval: string) => {
    // Set loading flag to prevent saving during data load
    isLoadingDataRef.current = true
    setLoading(true)

    try {
      const response = await fetch(`/api/btc-futures?symbol=${symbol}&interval=${interval}&limit=500`)
      if (!response.ok) throw new Error('Failed to fetch data')

      const data: ApiResponse = await response.json()

      const candlestickData: CandlestickData<Time>[] = data.candles.map((candle) => ({
        time: candle.time as Time,
        open: candle.open,
        high: candle.high,
        low: candle.low,
        close: candle.close,
      }))

      const volumeData: HistogramData<Time>[] = data.candles.map((candle) => ({
        time: candle.time as Time,
        value: candle.volume,
        color: candle.close >= candle.open ? 'rgba(34, 197, 94, 0.5)' : 'rgba(239, 68, 68, 0.5)',
      }))

      if (candlestickSeriesRef.current && volumeSeriesRef.current && chartRef.current) {
        const chart = chartRef.current
        const candlestickSeries = candlestickSeriesRef.current
        const volumeSeries = volumeSeriesRef.current
        const timeScale = chart.timeScale()
        
        // Update current refs BEFORE setting data
        currentSymbolRef.current = symbol
        currentIntervalRef.current = interval
        
        // Determine precision based on price
        const lastPrice = candlestickData[candlestickData.length - 1]?.close ?? 0
        let precision = 2
        let minMove = 0.01
        if (lastPrice >= 1000) {
          precision = 0
          minMove = 1
        } else if (lastPrice >= 1) {
          precision = 2
          minMove = 0.01
        } else if (lastPrice >= 0.01) {
          precision = 4
          minMove = 0.0001
        } else if (lastPrice >= 0.0001) {
          precision = 6
          minMove = 0.000001
        } else {
          precision = 8
          minMove = 0.00000001
        }
        
        // Update price format for this ticker
        candlestickSeries.applyOptions({
          priceFormat: {
            type: 'price',
            precision: precision,
            minMove: minMove,
          },
        })
        
        // Set new data
        candlestickSeries.setData(candlestickData)
        volumeSeries.setData(volumeData)
        
        // Get saved view state for this symbol+interval
        const key = `${symbol}-${interval}`
        const savedState = viewStateMapRef.current.get(key)
        
        if (savedState && savedState.logicalRange) {
          // Restore saved visible range and offset
          timeScale.setVisibleLogicalRange(savedState.logicalRange)
          timeScale.applyOptions({ rightOffset: savedState.rightOffset })
        } else {
          // First time viewing this chart - show last N bars
          // Add right offset to push chart to the left (away from price scale)
          const lastIndex = candlestickData.length - 1
          const fromIndex = Math.max(0, lastIndex - DEFAULT_VISIBLE_BARS)
          timeScale.setVisibleLogicalRange({
            from: fromIndex,
            to: lastIndex
          })
          // Apply right offset to shift chart left by 1/5 of visible bars
          const rightOffset = Math.floor(DEFAULT_VISIBLE_BARS / 5)
          timeScale.applyOptions({ rightOffset: rightOffset })
          // Save default state
          viewStateMapRef.current.set(key, {
            logicalRange: { from: fromIndex, to: lastIndex },
            rightOffset: rightOffset
          })
        }
        
        // Force price scale to auto-fit to new data
        candlestickSeries.priceScale().applyOptions({
          autoScale: true
        })
      }
    } finally {
      setLoading(false)
      // Delay re-enabling scale saving to ensure chart is stable
      setTimeout(() => {
        isLoadingDataRef.current = false
      }, 50)
    }
  }, [])

  // Initialize chart (only once)
  useEffect(() => {
    if (!chartContainerRef.current) return

    const chart = createChart(chartContainerRef.current, {
      layout: {
        background: { type: ColorType.Solid, color: 'transparent' },
        textColor: '#9ca3af',
      },
      grid: {
        vertLines: { color: 'rgba(107, 114, 128, 0.1)' },
        horzLines: { color: 'rgba(107, 114, 128, 0.1)' },
      },
      width: chartContainerRef.current.clientWidth,
      height: chartContainerRef.current.clientHeight,
      crosshair: {
        mode: 1,
        vertLine: { color: 'rgba(107, 114, 128, 0.4)', width: 1, style: 2 },
        horzLine: { color: 'rgba(107, 114, 128, 0.4)', width: 1, style: 2 },
      },
      rightPriceScale: { 
        borderColor: 'rgba(107, 114, 128, 0.3)',
        autoScale: true,
      },
      timeScale: { 
        borderColor: 'rgba(107, 114, 128, 0.3)', 
        timeVisible: true, 
        secondsVisible: false,
      },
    })

    // Hide TradingView attribution
    const container = chartContainerRef.current
    const style = document.createElement('style')
    style.textContent = `
      .tv-lightweight-charts { 
        overflow: hidden !important;
      }
      [class*="tv-lightweight-charts"] a,
      [class*="tv-lightweight-charts"] svg,
      [class*="attribution"],
      a[href*="tradingview"] {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
      }
    `
    container.appendChild(style)

    const candlestickSeries = chart.addSeries(CandlestickSeries, {
      upColor: '#22c55e',
      downColor: '#ef4444',
      borderUpColor: '#22c55e',
      borderDownColor: '#ef4444',
      wickUpColor: '#22c55e',
      wickDownColor: '#ef4444',
    })

    const volumeSeries = chart.addSeries(HistogramSeries, {
      priceFormat: { type: 'volume' },
      priceScaleId: '',
    })

    volumeSeries.priceScale().applyOptions({
      scaleMargins: { top: 0.8, bottom: 0 },
    })

    chartRef.current = chart
    candlestickSeriesRef.current = candlestickSeries
    volumeSeriesRef.current = volumeSeries

    // Subscribe to visible range changes to save when user zooms/scrolls
    const timeScale = chart.timeScale()
    
    const saveViewHandler = (range: LogicalRange | null) => {
      // Don't save during data load
      if (isLoadingDataRef.current) return
      if (!currentSymbolRef.current || !currentIntervalRef.current) return
      if (!range) return
      
      const options = timeScale.options()
      const key = `${currentSymbolRef.current}-${currentIntervalRef.current}`
      viewStateMapRef.current.set(key, { 
        logicalRange: range, 
        rightOffset: options.rightOffset ?? 0 
      })
    }
    
    timeScale.subscribeVisibleLogicalRangeChange(saveViewHandler)

    const handleResize = () => {
      if (chartContainerRef.current) {
        chart.applyOptions({
          width: chartContainerRef.current.clientWidth,
          height: chartContainerRef.current.clientHeight,
        })
      }
    }

    window.addEventListener('resize', handleResize)

    return () => {
      window.removeEventListener('resize', handleResize)
      chart.remove()
    }
  }, [])

  // Fetch data when symbol or interval changes
  useEffect(() => {
    if (chartRef.current && candlestickSeriesRef.current && volumeSeriesRef.current) {
      fetchData(selectedSymbol, selectedInterval)
    }
  }, [fetchData, selectedSymbol, selectedInterval])

  const handleTickerClick = (symbol: string) => {
    setSelectedSymbol(symbol)
  }

  const handleIntervalChange = (interval: string) => {
    setSelectedInterval(interval)
  }

  const formatVolume = (volume: number) => {
    if (volume >= 1e9) return `${(volume / 1e9).toFixed(0)}B`
    if (volume >= 1e6) return `${(volume / 1e6).toFixed(0)}M`
    if (volume >= 1e3) return `${(volume / 1e3).toFixed(0)}K`
    return volume.toFixed(0)
  }

  const formatCount = (count: number) => {
    if (count >= 1e6) return `${(count / 1e6).toFixed(1)}M`
    if (count >= 1e3) return `${(count / 1e3).toFixed(0)}K`
    return count.toString()
  }

  const formatChange = (change: number) => {
    const sign = change >= 0 ? '+' : ''
    return `${sign}${change.toFixed(1)}`
  }

  const formatPrice = (price: number) => {
    if (price >= 1000) return price.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })
    if (price >= 1) return price.toFixed(3)
    if (price >= 0.01) return price.toFixed(4)
    return price.toFixed(5)
  }

  // Calculate NATR-like volatility (simplified: range as % of price)
  const calcNATR = (ticker: Ticker) => {
    if (ticker.lastPrice === 0) return '0.0'
    const range = ((ticker.highPrice - ticker.lowPrice) / ticker.lastPrice) * 100
    return range.toFixed(1)
  }

  return (
    <div className="flex flex-col w-screen h-screen bg-background overflow-hidden">
      {/* Top Header Bar */}
      <div className="h-[28px] flex-shrink-0 border-b-2 border-border/80 bg-card flex items-center px-3">
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Tickers Sidebar */}
        <div className={`${showTickers ? 'w-[420px]' : 'w-0'} flex-shrink-0 border-r-2 border-border/80 bg-card flex flex-col h-full overflow-hidden transition-all duration-300`}>
          {/* Table Header */}
          <div className="relative flex py-2 text-[11px] text-muted-foreground border-b-2 border-border/80 flex-shrink-0 bg-card font-medium items-center">
            <div className="w-[80px] text-left px-2">Тикер</div>
            <div className="w-[75px] text-right">Цена</div>
            <div className="w-[50px] text-right">Изм</div>
            <div className="w-[45px] text-right">Ренж</div>
            <div className="w-[40px] text-right">NATR</div>
            <div className="w-[50px] text-right">Сделки</div>
            <div className="w-[50px] text-right">Объём</div>
            <button
              onClick={() => setShowTickers(false)}
              className="absolute right-0 top-0 bottom-0 w-2.5 bg-black hover:bg-zinc-800 flex items-center justify-center transition-colors"
            >
              <ChevronLeft className="w-2.5 h-2.5 text-white stroke-[3]" />
            </button>
          </div>

          {/* Tickers List */}
          <div className="flex-1 min-h-0 overflow-hidden">
            <ScrollArea className="h-full border-l-2 border-border/80" scrollBarClassName="bg-black hover:bg-zinc-800">
              <div>
                {tickersLoading ? (
                  <div className="p-3 text-center text-muted-foreground text-sm">Загрузка...</div>
                ) : (
                  <div>
                    {tickers.map((ticker) => (
                      <button
                        key={ticker.symbol}
                        onClick={() => handleTickerClick(ticker.symbol)}
                        className={`w-full flex items-center py-2 text-xs transition-colors ${
                          selectedSymbol === ticker.symbol 
                            ? 'bg-accent border-2 border-primary' 
                            : 'border-b border-border/50 hover:bg-accent/90'
                        }`}
                      >
                        {/* Ticker */}
                        <div className="w-[80px] flex items-center gap-1 text-left flex-shrink-0 px-2">
                          {ticker.priceChangePercent >= 0 ? (
                            <TrendingUp className="w-3 h-3 flex-shrink-0 text-green-500" />
                          ) : (
                            <TrendingDown className="w-3 h-3 flex-shrink-0 text-red-500" />
                          )}
                          <span className="font-medium">{ticker.baseAsset}</span>
                        </div>
                        
                        {/* Price */}
                        <div className="w-[75px] text-right tabular-nums flex-shrink-0">
                          {formatPrice(ticker.lastPrice)}
                        </div>
                        
                        {/* Daily Change */}
                        <div className={`w-[50px] text-right tabular-nums flex-shrink-0 ${
                          ticker.priceChangePercent >= 0 ? 'text-green-500' : 'text-red-500'
                        }`}>
                          {formatChange(ticker.priceChangePercent)}
                        </div>
                        
                        {/* Range */}
                        <div className="w-[45px] text-right text-[11px] tabular-nums text-muted-foreground flex-shrink-0">
                          {calcNATR(ticker)}%
                        </div>
                        
                        {/* NATR */}
                        <div className="w-[40px] text-right text-[11px] tabular-nums text-muted-foreground flex-shrink-0">
                          {calcNATR(ticker)}
                        </div>
                        
                        {/* Count (Trades) */}
                        <div className="w-[50px] text-right text-[11px] tabular-nums text-muted-foreground flex-shrink-0">
                          {formatCount(ticker.count)}
                        </div>
                        
                        {/* Volume */}
                        <div className="w-[50px] text-right text-[11px] tabular-nums flex-shrink-0">
                          {formatVolume(ticker.volume)}
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </ScrollArea>
          </div>
        </div>

        {/* Show Tickers Button (when hidden) */}
        {!showTickers && (
          <div className="flex-shrink-0 border-r-2 border-border/80 bg-card flex flex-col h-full">
            <div className="h-[36px] flex items-center justify-center border-b-2 border-border/80">
              <button
                onClick={() => setShowTickers(true)}
                className="p-1 text-xs font-medium rounded transition-colors bg-primary text-primary-foreground hover:bg-primary/80"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Chart */}
        <div className="flex-1 h-full overflow-hidden relative">
          {/* Top Bar with Symbol Info and Timeframe Buttons */}
          <div className="absolute top-0 left-0 right-0 z-20 flex items-center h-[36px] px-3 border-b-2 border-border/80">
            {/* Ticker Navigation */}
            <div className="flex items-center gap-1">
              <button
                onClick={() => {
                  const currentIndex = tickers.findIndex(t => t.symbol === selectedSymbol)
                  if (currentIndex > 0) {
                    setSelectedSymbol(tickers[currentIndex - 1].symbol)
                  }
                }}
                className="p-1 text-xs font-medium rounded transition-colors bg-primary text-primary-foreground hover:bg-primary/80"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={() => {
                  const currentIndex = tickers.findIndex(t => t.symbol === selectedSymbol)
                  if (currentIndex < tickers.length - 1) {
                    setSelectedSymbol(tickers[currentIndex + 1].symbol)
                  }
                }}
                className="p-1 text-xs font-medium rounded transition-colors bg-primary text-primary-foreground hover:bg-primary/80"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center gap-2 ml-2">
              <span className="text-xs font-medium">{selectedSymbol}</span>
              <span className="text-xs text-muted-foreground">Perpetual</span>
            </div>
            {tickers.find(t => t.symbol === selectedSymbol) && (
              <>
                <span className="tabular-nums text-xs ml-4">{formatPrice(tickers.find(t => t.symbol === selectedSymbol)!.lastPrice)}</span>
                <span className={`tabular-nums text-xs ml-2 ${tickers.find(t => t.symbol === selectedSymbol)!.priceChangePercent >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                  {formatChange(tickers.find(t => t.symbol === selectedSymbol)!.priceChangePercent)}%
                </span>
                <span className="tabular-nums text-xs text-muted-foreground ml-2">R: {calcNATR(tickers.find(t => t.symbol === selectedSymbol)!)}%</span>
                <span className="tabular-nums text-xs text-muted-foreground ml-2">NATR: {calcNATR(tickers.find(t => t.symbol === selectedSymbol)!)}</span>
                <span className="tabular-nums text-xs text-muted-foreground ml-2">Сделки: {formatCount(tickers.find(t => t.symbol === selectedSymbol)!.count)}</span>
                <span className="tabular-nums text-xs text-muted-foreground ml-2">Объём: {formatVolume(tickers.find(t => t.symbol === selectedSymbol)!.volume)}</span>
              </>
            )}

            {/* Timeframe Buttons */}
            <div className="flex items-center gap-1 ml-4">
              {timeframes.map((tf) => (
                <button
                  key={tf}
                  onClick={() => handleIntervalChange(tf)}
                  className={`px-2 py-1 text-xs font-medium rounded transition-colors ${
                    selectedInterval === tf
                      ? 'bg-card text-foreground underline decoration-2 underline-offset-4'
                      : 'bg-card hover:bg-accent text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {tf}
                </button>
              ))}
            </div>
          </div>
          {loading && (
            <div className="absolute inset-0 flex items-center justify-center bg-background/50 z-10">
              <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            </div>
          )}
          <div ref={chartContainerRef} className="w-full h-full" />
        </div>

        {/* Empty block when tickers are hidden */}
        {!showTickers && (
          <div className="flex-shrink-0 w-[420px] border-l-2 border-border/80 bg-card h-full transition-all duration-300" />
        )}
      </div>
    </div>
  )
}

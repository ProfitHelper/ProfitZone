import { NextRequest, NextResponse } from 'next/server'

interface BinanceKline {
  0: number // Open time
  1: string // Open
  2: string // High
  3: string // Low
  4: string // Close
  5: string // Volume
  6: number // Close time
  7: string // Quote asset volume
  8: number // Number of trades
  9: string // Taker buy base asset volume
  10: string // Taker buy quote asset volume
  11: string // Ignore
}

interface CandleData {
  time: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const symbol = searchParams.get('symbol') || 'BTCUSDT'
  const interval = searchParams.get('interval') || '1h'
  const limit = parseInt(searchParams.get('limit') || '500')

  try {
    // Binance Futures API
    const response = await fetch(
      `https://fapi.binance.com/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`,
      {
        headers: {
          'Content-Type': 'application/json',
        },
      }
    )

    if (!response.ok) {
      throw new Error(`Binance API error: ${response.status}`)
    }

    const data: BinanceKline[] = await response.json()

    const candles: CandleData[] = data.map((kline) => ({
      time: Math.floor(kline[0] / 1000), // Convert to seconds for lightweight-charts
      open: parseFloat(kline[1]),
      high: parseFloat(kline[2]),
      low: parseFloat(kline[3]),
      close: parseFloat(kline[4]),
      volume: parseFloat(kline[5]),
    }))

    return NextResponse.json({
      symbol,
      interval,
      candles,
    })
  } catch (error) {
    console.error('Error fetching futures data:', error)
    return NextResponse.json(
      { error: 'Failed to fetch futures data' },
      { status: 500 }
    )
  }
}

import { NextResponse } from 'next/server'

interface BinanceTicker {
  symbol: string
  priceChange: string
  priceChangePercent: string
  lastPrice: string
  highPrice: string
  lowPrice: string
  volume: string
  quoteVolume: string
  count: number
}

interface TickerInfo {
  symbol: string
  baseAsset: string
  priceChangePercent: number
  lastPrice: number
  highPrice: number
  lowPrice: number
  volume: number
  count: number
}

export async function GET() {
  try {
    // Get exchange info to filter active perpetual futures
    const exchangeInfoResponse = await fetch('https://fapi.binance.com/fapi/v1/exchangeInfo')
    if (!exchangeInfoResponse.ok) {
      throw new Error('Failed to fetch exchange info')
    }
    const exchangeInfo = await exchangeInfoResponse.json()

    // Get active USDT perpetual futures symbols (exclude delisted)
    const activeSymbols = new Set(
      exchangeInfo.symbols
        .filter((s: { status: string; contractType: string; quoteAsset: string }) =>
          s.status === 'TRADING' &&
          s.contractType === 'PERPETUAL' &&
          s.quoteAsset === 'USDT'
        )
        .map((s: { symbol: string }) => s.symbol)
    )

    // Get 24h ticker data
    const tickerResponse = await fetch('https://fapi.binance.com/fapi/v1/ticker/24hr')
    if (!tickerResponse.ok) {
      throw new Error('Failed to fetch ticker data')
    }
    const tickers: BinanceTicker[] = await tickerResponse.json()

    // Filter and format tickers
    const formattedTickers: TickerInfo[] = tickers
      .filter((t) => activeSymbols.has(t.symbol))
      .map((t) => ({
        symbol: t.symbol,
        baseAsset: t.symbol.replace('USDT', ''),
        priceChangePercent: parseFloat(t.priceChangePercent),
        lastPrice: parseFloat(t.lastPrice),
        highPrice: parseFloat(t.highPrice),
        lowPrice: parseFloat(t.lowPrice),
        volume: parseFloat(t.quoteVolume),
        count: t.count,
      }))
      .sort((a, b) => b.volume - a.volume) // Sort by volume

    return NextResponse.json({
      tickers: formattedTickers,
      count: formattedTickers.length,
    })
  } catch (error) {
    console.error('Error fetching tickers:', error)
    return NextResponse.json(
      { error: 'Failed to fetch tickers' },
      { status: 500 }
    )
  }
}

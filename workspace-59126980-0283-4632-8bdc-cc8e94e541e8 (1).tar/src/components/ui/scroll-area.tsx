"use client"

import * as React from "react"
import * as ScrollAreaPrimitive from "@radix-ui/react-scroll-area"

import { cn } from "@/lib/utils"

interface ScrollAreaProps extends React.ComponentProps<typeof ScrollAreaPrimitive.Root> {
  scrollBarClassName?: string
  onScroll?: (e: React.UIEvent<HTMLDivElement>) => void
}

function ScrollArea({
  className,
  scrollBarClassName,
  children,
  onScroll,
  ...props
}: ScrollAreaProps) {
  const rootRef = React.useRef<HTMLDivElement>(null)

  // 1. Блокируем pointerleave ДО того как Radix добавит свой listener
  React.useLayoutEffect(() => {
    const root = rootRef.current
    if (!root) return

    // Добавляем listener в capture phase ПЕРЕД Radix
    root.addEventListener('pointerleave', (e) => {
      e.stopImmediatePropagation()
    }, true)
  }, [])

  // 2. Отправляем pointerenter ПОСЛЕ того как Radix добавит свой listener
  React.useEffect(() => {
    const root = rootRef.current
    if (!root) return

    // Ждём следующий frame когда Radix уже добавил listeners
    const raf = requestAnimationFrame(() => {
      const enterEvent = new PointerEvent('pointerenter', {
        bubbles: true,
        cancelable: true,
        pointerType: 'mouse'
      })
      root.dispatchEvent(enterEvent)
    })

    return () => cancelAnimationFrame(raf)
  }, [])

  return (
    <ScrollAreaPrimitive.Root
      ref={rootRef}
      data-slot="scroll-area"
      className={cn("relative", className)}
      {...props}
    >
      <ScrollAreaPrimitive.Viewport
        data-slot="scroll-area-viewport"
        className="focus-visible:ring-ring/50 size-full rounded-[inherit] transition-[color,box-shadow] outline-none focus-visible:ring-[3px] focus-visible:outline-1"
        onScroll={onScroll}
      >
        {children}
      </ScrollAreaPrimitive.Viewport>
      <ScrollBar className={scrollBarClassName} />
      <ScrollAreaPrimitive.Corner />
    </ScrollAreaPrimitive.Root>
  )
}

const ScrollBar = React.forwardRef<
  React.ElementRef<typeof ScrollAreaPrimitive.ScrollAreaScrollbar>,
  React.ComponentProps<typeof ScrollAreaPrimitive.ScrollAreaScrollbar>
>(({ className, orientation = "vertical", ...props }, ref) => {
  const scrollbarRef = React.useRef<HTMLDivElement>(null)

  // 2 + 3. MutationObserver + useLayoutEffect (срабатывает до отрисовки)
  React.useLayoutEffect(() => {
    const el = scrollbarRef.current
    if (!el) return

    // Устанавливаем opacity сразу
    el.style.setProperty('opacity', '1', 'important')

    // MutationObserver отслеживает изменения
    const observer = new MutationObserver(() => {
      if (el.style.opacity !== '1') {
        el.style.setProperty('opacity', '1', 'important')
      }
    })
    observer.observe(el, { attributes: true, attributeFilter: ['style'] })

    return () => observer.disconnect()
  }, [])

  return (
    <ScrollAreaPrimitive.ScrollAreaScrollbar
      ref={scrollbarRef}
      data-slot="scroll-area-scrollbar"
      orientation={orientation}
      className={cn(
        "flex touch-none p-px select-none",
        orientation === "vertical" &&
          "h-full w-2.5 border-l border-l-transparent",
        orientation === "horizontal" &&
          "h-2.5 flex-col border-t border-t-transparent",
        className
      )}
      {...props}
    >
      <ScrollAreaPrimitive.ScrollAreaThumb
        data-slot="scroll-area-thumb"
        className="bg-border relative flex-1 rounded-full"
      />
    </ScrollAreaPrimitive.ScrollAreaScrollbar>
  )
})

ScrollBar.displayName = "ScrollBar"

export { ScrollArea, ScrollBar }

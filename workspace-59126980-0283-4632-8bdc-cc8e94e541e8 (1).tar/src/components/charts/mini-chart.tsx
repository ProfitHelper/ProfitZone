'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import { Expand } from 'lucide-react'
import {
  createChart,
  IChartApi,
  ISeriesApi,
  CandlestickData,
  HistogramData,
  ColorType,
  Time,
  CandlestickSeries,
  HistogramSeries,
  CandlestickSeriesOptions,
  HistogramSeriesOptions,
  LogicalRange,
} from 'lightweight-charts'

interface CandleData {
  time: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

interface ApiResponse {
  symbol: string
  interval: string
  candles: CandleData[]
}

interface ChartViewState {
  logicalRange: LogicalRange | null
  rightOffset: number
}

interface TickerInfo {
  priceChangePercent: number
  lastPrice: number
  highPrice: number
  lowPrice: number
  volume: number
  count: number
}

interface MiniChartProps {
  symbol: string
  interval?: string
  limit?: number
  showVolume?: boolean
  ticker?: TickerInfo
  onIntervalChange?: (interval: string) => void
  onFavorite?: (symbol: string) => void
  onExpand?: (symbol: string) => void
}

const timeframes = ['1m', '5m', '15m', '1h', '4h', '1d']

const colorOptions = [
  { name: 'red', class: 'bg-red-500' },
  { name: 'green', class: 'bg-green-500' },
  { name: 'blue', class: 'bg-blue-500' },
  { name: 'yellow', class: 'bg-yellow-400' },
  { name: 'purple', class: 'bg-purple-500' },
]

export function MiniChart({ 
  symbol, 
  interval = '5m', 
  limit = 500,
  showVolume = true,
  ticker,
  onIntervalChange,
  onFavorite,
  onExpand
}: MiniChartProps) {
  const chartContainerRef = useRef<HTMLDivElement>(null)
  const chartRef = useRef<IChartApi | null>(null)
  const candlestickSeriesRef = useRef<ISeriesApi<'Candlestick', Time, CandlestickData<Time>, CandlestickSeriesOptions> | null>(null)
  const volumeSeriesRef = useRef<ISeriesApi<'Histogram', Time, HistogramData<Time>, HistogramSeriesOptions> | null>(null)

  const viewStateMapRef = useRef<Map<string, ChartViewState>>(new Map())
  const isLoadingDataRef = useRef(false)
  const currentSymbolRef = useRef<string>('')
  const currentIntervalRef = useRef<string>('')

  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)
  const [copied, setCopied] = useState(false)
  const [selectedColor, setSelectedColor] = useState<string | null>(null)

  const DEFAULT_VISIBLE_BARS = 100

  // Helpers
  const formatPrice = (price: number) => {
    if (price >= 1000) return price.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 0 })
    if (price >= 1) return price.toFixed(3)
    if (price >= 0.01) return price.toFixed(4)
    return price.toFixed(5)
  }

  const formatChange = (change: number) => {
    const sign = change >= 0 ? '+' : ''
    return `${sign}${change.toFixed(1)}`
  }

  const formatVolume = (volume: number) => {
    if (volume >= 1e9) return `${(volume / 1e9).toFixed(1)}B`
    if (volume >= 1e6) return `${(volume / 1e6).toFixed(1)}M`
    if (volume >= 1e3) return `${(volume / 1e3).toFixed(0)}K`
    return volume.toFixed(0)
  }

  const formatCount = (count: number) => {
    if (count >= 1e6) return `${(count / 1e6).toFixed(1)}M`
    if (count >= 1e3) return `${(count / 1e3).toFixed(0)}K`
    return count.toString()
  }

  const calcNATR = () => {
    if (!ticker || ticker.lastPrice === 0) return '0.0'
    const range = ((ticker.highPrice - ticker.lowPrice) / ticker.lastPrice) * 100
    return range.toFixed(1)
  }

  // Fetch data
  const fetchData = useCallback(async () => {
    if (!chartRef.current || !candlestickSeriesRef.current || !volumeSeriesRef.current) return

    isLoadingDataRef.current = true
    setLoading(true)
    setError(false)

    try {
      const response = await fetch(`/api/btc-futures?symbol=${symbol}&interval=${interval}&limit=${limit}`)
      if (!response.ok) throw new Error('Failed to fetch')

      const data: ApiResponse = await response.json()

      const candlestickData: CandlestickData<Time>[] = data.candles.map((candle) => ({
        time: candle.time as Time,
        open: candle.open,
        high: candle.high,
        low: candle.low,
        close: candle.close,
      }))

      const volumeData: HistogramData<Time>[] = data.candles.map((candle) => ({
        time: candle.time as Time,
        value: candle.volume,
        color: candle.close >= candle.open ? 'rgba(34, 197, 94, 0.5)' : 'rgba(239, 68, 68, 0.5)',
      }))

      const chart = chartRef.current
      const candlestickSeries = candlestickSeriesRef.current
      const volumeSeries = volumeSeriesRef.current
      const timeScale = chart.timeScale()

      currentSymbolRef.current = symbol
      currentIntervalRef.current = interval

      const lastPrice = candlestickData[candlestickData.length - 1]?.close ?? 0

      // Determine precision
      let precision = 2
      let minMove = 0.01
      if (lastPrice >= 1000) {
        precision = 0
        minMove = 1
      } else if (lastPrice >= 1) {
        precision = 2
        minMove = 0.01
      } else if (lastPrice >= 0.01) {
        precision = 4
        minMove = 0.0001
      } else if (lastPrice >= 0.0001) {
        precision = 6
        minMove = 0.000001
      } else {
        precision = 8
        minMove = 0.00000001
      }

      candlestickSeries.applyOptions({
        priceFormat: { type: 'price', precision, minMove },
      })

      candlestickSeries.setData(candlestickData)
      
      if (showVolume) {
        volumeSeries.setData(volumeData)
      }

      // Restore or set default view
      const key = `${symbol}-${interval}`
      const savedState = viewStateMapRef.current.get(key)

      if (savedState && savedState.logicalRange) {
        timeScale.setVisibleLogicalRange(savedState.logicalRange)
        timeScale.applyOptions({ rightOffset: savedState.rightOffset })
      } else {
        const lastIndex = candlestickData.length - 1
        const fromIndex = Math.max(0, lastIndex - DEFAULT_VISIBLE_BARS)
        timeScale.setVisibleLogicalRange({
          from: fromIndex,
          to: lastIndex
        })
        const rightOffset = Math.floor(DEFAULT_VISIBLE_BARS / 5)
        timeScale.applyOptions({ rightOffset })
        viewStateMapRef.current.set(key, {
          logicalRange: { from: fromIndex, to: lastIndex },
          rightOffset
        })
      }

      candlestickSeries.priceScale().applyOptions({ autoScale: true })
      setLoading(false)
    } catch {
      setError(true)
      setLoading(false)
    } finally {
      setTimeout(() => {
        isLoadingDataRef.current = false
      }, 50)
    }
  }, [symbol, interval, limit, showVolume])

  // Initialize chart
  useEffect(() => {
    if (!chartContainerRef.current) return

    const container = chartContainerRef.current
    const chart = createChart(container, {
      layout: {
        background: { type: ColorType.Solid, color: 'transparent' },
        textColor: '#9ca3af',
      },
      grid: {
        vertLines: { color: 'rgba(107, 114, 128, 0.1)' },
        horzLines: { color: 'rgba(107, 114, 128, 0.1)' },
      },
      width: container.clientWidth,
      height: container.clientHeight,
      crosshair: {
        mode: 1,
        vertLine: { color: 'rgba(107, 114, 128, 0.4)', width: 1, style: 2 },
        horzLine: { color: 'rgba(107, 114, 128, 0.4)', width: 1, style: 2 },
      },
      rightPriceScale: { 
        borderColor: 'rgba(107, 114, 128, 0.3)',
        autoScale: true,
      },
      timeScale: { 
        borderColor: 'rgba(107, 114, 128, 0.3)', 
        timeVisible: true, 
        secondsVisible: false,
        visible: false,
      },
    })

    const style = document.createElement('style')
    style.textContent = `
      .tv-lightweight-charts { 
        overflow: hidden !important;
      }
      [class*="tv-lightweight-charts"] a,
      [class*="tv-lightweight-charts"] svg,
      [class*="attribution"],
      a[href*="tradingview"] {
        display: none !important;
        visibility: hidden !important;
        opacity: 0 !important;
      }
    `
    container.appendChild(style)

    const candlestickSeries = chart.addSeries(CandlestickSeries, {
      upColor: '#22c55e',
      downColor: '#ef4444',
      borderUpColor: '#22c55e',
      borderDownColor: '#ef4444',
      wickUpColor: '#22c55e',
      wickDownColor: '#ef4444',
    })

    const volumeSeries = chart.addSeries(HistogramSeries, {
      priceFormat: { type: 'volume' },
      priceScaleId: '',
    })

    volumeSeries.priceScale().applyOptions({
      scaleMargins: { top: 0.8, bottom: 0 },
    })

    chartRef.current = chart
    candlestickSeriesRef.current = candlestickSeries
    volumeSeriesRef.current = volumeSeries

    const timeScale = chart.timeScale()
    
    const saveViewHandler = (range: LogicalRange | null) => {
      if (isLoadingDataRef.current) return
      if (!currentSymbolRef.current || !currentIntervalRef.current) return
      if (!range) return
      
      const options = timeScale.options()
      const key = `${currentSymbolRef.current}-${currentIntervalRef.current}`
      viewStateMapRef.current.set(key, { 
        logicalRange: range, 
        rightOffset: options.rightOffset ?? 0 
      })
    }
    
    timeScale.subscribeVisibleLogicalRangeChange(saveViewHandler)

    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        if (entry.contentRect.width > 0 && entry.contentRect.height > 0) {
          chart.applyOptions({
            width: entry.contentRect.width,
            height: entry.contentRect.height,
          })
        }
      }
    })
    resizeObserver.observe(container)

    return () => {
      resizeObserver.disconnect()
      chart.remove()
      chartRef.current = null
      candlestickSeriesRef.current = null
      volumeSeriesRef.current = null
    }
  }, [])

  // Fetch data when symbol/interval changes
  useEffect(() => {
    if (chartRef.current && candlestickSeriesRef.current && volumeSeriesRef.current) {
      fetchData()
    }
  }, [fetchData])

  return (
    <div className="relative w-full h-full flex flex-col">
      {/* Info Bar */}
      <div className="flex items-center h-[28px] px-2 border-b border-border/50 bg-card/50 flex-shrink-0 gap-1">
        <span 
          className="text-xs font-bold flex-shrink-0 px-1.5 py-0.5 border border-foreground/30 rounded cursor-pointer hover:bg-accent transition-colors"
          onClick={() => {
            navigator.clipboard.writeText(symbol)
            setCopied(true)
            setTimeout(() => setCopied(false), 1000)
          }}
        >
          {copied ? 'Скопировано' : symbol.replace('USDT', '')}
        </span>
        <span className="text-xs font-semibold text-foreground/60 flex-shrink-0">Perp</span>
        {ticker && (
          <>
            <span className="text-xs font-bold tabular-nums flex-shrink-0 ml-2">{formatPrice(ticker.lastPrice)}</span>
            <span className={`text-xs font-bold tabular-nums flex-shrink-0 ${ticker.priceChangePercent >= 0 ? 'text-green-500' : 'text-red-500'}`}>
              {formatChange(ticker.priceChangePercent)}%
            </span>
            <span className="text-xs font-semibold tabular-nums text-foreground/80 flex-shrink-0 ml-3">R:{calcNATR()}%</span>
            <span className="text-xs font-semibold tabular-nums text-foreground/80 flex-shrink-0 ml-2">NATR:{calcNATR()}</span>
            <span className="text-xs font-semibold tabular-nums text-foreground/80 flex-shrink-0 ml-2">Trd:{formatCount(ticker.count)}</span>
            <span className="text-xs font-semibold tabular-nums text-foreground/80 flex-shrink-0 ml-2">Vol:{formatVolume(ticker.volume)}</span>
          </>
        )}
      </div>

      {/* Chart */}
      <div className="flex-1 min-h-0 relative">
        {loading && (
          <div className="absolute inset-0 flex items-center justify-center bg-background/50 z-10">
            <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        )}
        {error && (
          <div className="absolute inset-0 flex items-center justify-center bg-background/50 z-10">
            <span className="text-xs text-muted-foreground">Error</span>
          </div>
        )}
        <div ref={chartContainerRef} className="w-full h-full" />
      </div>

      {/* Timeframe Buttons */}
      <div className="flex items-center justify-between px-2 h-[24px] border-t border-border/50 bg-card/50 flex-shrink-0">
        {/* Color buttons */}
        <div className="flex items-center gap-0.5 w-[68px]">
          {colorOptions.map((color) => (
            <button
              key={color.name}
              onClick={() => {
                setSelectedColor(selectedColor === color.name ? null : color.name)
                onFavorite?.(symbol)
              }}
              className={`w-3 h-3 transition-all ${color.class} ${
                selectedColor === color.name 
                  ? 'ring-2 ring-foreground ring-offset-1 ring-offset-background' 
                  : selectedColor 
                    ? 'invisible' 
                    : 'opacity-50 hover:opacity-100'
              }`}
            />
          ))}
        </div>
        
        {/* Timeframes */}
        <div className="flex items-center gap-0.5">
          {timeframes.map((tf) => (
            <button
              key={tf}
              onClick={() => onIntervalChange?.(tf)}
              className={`px-1.5 py-0.5 text-[10px] font-semibold rounded transition-colors ${
                interval === tf
                  ? 'bg-primary text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>
        
        {/* Expand button */}
        <div className="flex items-center">
          <button
            onClick={() => onExpand?.(symbol)}
            className="p-1 rounded transition-colors hover:bg-accent"
          >
            <Expand className="w-3.5 h-3.5 text-black" />
          </button>
        </div>
      </div>
    </div>
  )
}
